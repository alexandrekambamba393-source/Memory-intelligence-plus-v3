#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Memory Intelligence engine
==========================

A local-first personal knowledge and conversation-intelligence engine.
It imports conversation records the user actually provides (JSON, JSONL, CSV,
TXT, Markdown, ZIP archives), stores them in a persistent SQLite database with
FTS5 full-text search, and offers search, reasoning helpers, statistics,
numerical analysis, project tracking, contradiction review, timelines and
exports (JSON, JSONL, CSV, TXT, Markdown, HTML, PDF, DOCX).

IMPORTANT HONESTY RULE
    This engine NEVER reads Claude's private account-wide history. It only
    analyses data that was imported into its database. Every output separates
    (1) information present in records, (2) inferred information (heuristics)
    and (3) information that is not available.

Architecture (all in this single file)
    1. Utilities ........ text, dates, encodings, hashing
    2. Ingestion ........ Normalizer, file readers, Importer
    3. MemoryDB ......... SQLite schema, FTS5, transactions, backup/restore
    4. SearchEngine ..... keyword / FTS / contextual / semantic + filters
    5. Statements ....... StatementExtractor, Reasoner (evidence packs, etc.)
    6. Analytics ........ statistics and period comparison
    7. NumericEngine .... safe calculator, number extraction, aggregation
    8. ProjectEngine .... project discovery, tracking, reports
    9. Contradictions ... review-queue generation
   10. Timeline ......... chronological reconstruction
   11. Reports/Export ... renderers for all formats
   12. CLI .............. argparse front-end (run `help`)

Security model
    * Local only: no network modules are imported; embedding models are loaded
      with local_files_only and offline environment flags.
    * Imported text is untrusted DATA. It is stored with parameterised SQL,
      never executed, never evaluated, never unpickled.
    * Records that look like prompt-injection attempts are flagged.
    * Destructive operations (restore, purge) require --yes and make a safety
      backup first.

Optional dependencies (all optional; the core uses only the standard library)
    reportlab ............ PDF export        (pip install reportlab)
    python-docx .......... DOCX export       (pip install python-docx)
    sentence-transformers  semantic search   (pip install sentence-transformers,
                                              model must already be on disk)
    numpy ................ faster vector math for semantic search
    chardet .............. better encoding detection
"""
from __future__ import annotations

import argparse
import array
import ast
import calendar
import codecs
import collections
import contextlib
import csv
import datetime as dt
import hashlib
import html
import io
import json
import logging
import math
import os
import re
import shutil
import sqlite3
import statistics
import sys
import textwrap
import time
import unicodedata
import zipfile
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation, getcontext
from pathlib import Path
from typing import (Any, Callable, Dict, Iterable, Iterator, List, Optional,
                    Sequence, Set, Tuple)

__version__ = "1.0.0"
SCHEMA_VERSION = 1
LOG = logging.getLogger("memory_intelligence")

ENV_HOME = "MEMORY_INTELLIGENCE_HOME"
ENV_MODEL = "MEMORY_INTELLIGENCE_MODEL"
DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

MAX_FILE_BYTES = 2 * 1024 ** 3
MAX_JSON_BYTES = 768 * 1024 ** 2
MAX_RECORD_CHARS = 200_000
MAX_ZIP_MEMBERS = 5_000
MAX_ZIP_MEMBER_BYTES = 768 * 1024 ** 2
MAX_ZIP_TOTAL_BYTES = 4 * 1024 ** 3
SUPPORTED_EXTS = {".json", ".jsonl", ".ndjson", ".csv", ".tsv", ".txt", ".md",
                  ".markdown", ".zip"}
DATE_DAYFIRST = False  # ambiguous 03/04/2026 -> month first unless --dayfirst


# --------------------------------------------------------------------------
# 1. Errors
# --------------------------------------------------------------------------
class MemoryEngineError(Exception):
    """Base class for all expected engine errors (shown without traceback)."""


class ValidationError(MemoryEngineError):
    """Invalid user input or invalid data."""


class IngestError(MemoryEngineError):
    """A file could not be imported."""


class DependencyError(MemoryEngineError):
    """An optional dependency is missing."""


class ConfirmationRequired(MemoryEngineError):
    """A destructive operation was requested without explicit confirmation."""


class NotFoundError(MemoryEngineError):
    """A requested object does not exist."""


# --------------------------------------------------------------------------
# 1. Text utilities
# --------------------------------------------------------------------------
STOPWORDS_EN = set("""
a about above after again against all also am an and any are aren't as at be because been before being below between
both but by can can't cannot could couldn't did didn't do does doesn't doing don't down during each few for from
further get got had hadn't has hasn't have haven't having he her here hers herself him himself his how i i'd i'll i'm
i've if in into is isn't it it's its itself just let's like me more most mustn't my myself no nor not now of off on once
only or other ought our ours ourselves out over own same shan't she should shouldn't so some such than that that's the
their theirs them themselves then there there's these they they'd they'll they're they've this those through to too
under until up us very was wasn't we we'd we'll we're we've were weren't what what's when where which while who who's
whom why will with won't would wouldn't you you'd you'll you're you've your yours yourself yourselves yes please thanks
thank ok okay want need would use using used make made one two get also really will let know think going go want
""".split())
STOPWORDS_FR = set("""
au aux avec ce ces dans de des du elle en et eux il ils je la le les leur lui ma mais me même mes moi mon ne nos notre
nous on ou par pas pour qu que qui sa se ses son sur ta te tes toi ton tu un une vos votre vous c d j l à m n s t y été
être avoir est sont suis es sommes êtes fait faire peut peux veux veut cette cet ça comme plus très donc car si aussi
bien alors tout tous toute toutes merci svp
""".split())
STOPWORDS = STOPWORDS_EN | STOPWORDS_FR

_FR_ELISION = {"l", "d", "j", "n", "s", "c", "m", "t", "qu", "jusqu", "lorsqu", "puisqu"}
_TOKEN_RE = re.compile(r"[^\W_]+(?:['’\-][^\W_]+)*", re.UNICODE)
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_XML_BAD_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff￾￿]")

SYNONYM_GROUPS: List[Set[str]] = [
    {"buy", "purchase", "acquire", "order"},
    {"cost", "price", "pricing", "budget", "expense", "fee", "spend", "spending"},
    {"bug", "error", "issue", "defect", "glitch", "problem", "fault"},
    {"fix", "repair", "patch", "resolve", "solve"},
    {"job", "work", "employment", "career", "position"},
    {"car", "vehicle", "auto", "automobile"},
    {"house", "home", "apartment", "flat", "property"},
    {"trip", "travel", "journey", "vacation", "holiday"},
    {"deadline", "due", "cutoff", "timeline", "schedule"},
    {"goal", "objective", "aim", "target", "purpose"},
    {"start", "begin", "launch", "kickoff", "initiate"},
    {"finish", "complete", "end", "done", "wrap"},
    {"money", "cash", "funds", "funding", "finance", "capital"},
    {"app", "application", "software", "program"},
    {"website", "site", "webpage", "web"},
    {"doctor", "physician", "clinic", "hospital"},
    {"learn", "study", "course", "training", "tutorial"},
    {"meeting", "call", "appointment", "sync"},
    {"customer", "client", "buyer"},
    {"salary", "pay", "wage", "income", "earnings"},
    {"team", "staff", "colleague", "employee"},
    {"plan", "strategy", "roadmap", "approach"},
    {"database", "db", "sql", "datastore"},
    {"test", "testing", "qa", "verify", "validation"},
    {"design", "layout", "mockup", "wireframe"},
    {"slow", "latency", "performance", "lag"},
    {"prix", "coût", "cout", "budget", "tarif"},
    {"erreur", "bug", "problème", "probleme", "panne"},
    {"voiture", "véhicule", "vehicule", "auto"},
    {"travail", "emploi", "boulot", "carrière", "carriere"},
    {"voyage", "vacances", "séjour", "sejour"},
    {"objectif", "but", "cible"},
]
_SYN_MAP: Dict[str, Set[str]] = collections.defaultdict(set)
for _g in SYNONYM_GROUPS:
    for _w in _g:
        _SYN_MAP[_w] |= (_g - {_w})

_SUFFIXES = ("izations", "ization", "isations", "isation", "ations", "ation",
             "ments", "ment", "nesses", "ness", "ities", "ity", "ingly", "ings",
             "ing", "edly", "ies", "ied", "ers", "er", "ed", "es", "ly", "s")


def clean_text(s: str) -> str:
    """Normalise newlines, drop control characters, NFC-normalise, strip."""
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = _CTRL_RE.sub("", s)
    return unicodedata.normalize("NFC", s).strip()


def xml_safe(s: str) -> str:
    """Remove characters that are illegal in XML (needed for DOCX/PDF)."""
    return _XML_BAD_RE.sub("", s)


def tokenize(text: str) -> List[str]:
    """Lower-case word tokens; French elisions (l'app) are split."""
    out: List[str] = []
    for t in _TOKEN_RE.findall(text):
        t = t.lower().replace("’", "'")
        if "'" in t:
            head, _, tail = t.partition("'")
            if head in _FR_ELISION and tail:
                t = tail
        out.append(t)
    return out


def stem(w: str) -> str:
    """Very light suffix stemmer (EN/FR friendly, deterministic)."""
    if len(w) <= 3 or not w.isalpha():
        return w
    for suf in _SUFFIXES:
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    if len(w) > 3 and w.endswith("y"):
        w = w[:-1] + "i"
    return w


def content_tokens(text: str, do_stem: bool = False, min_len: int = 2) -> List[str]:
    """Tokens without stopwords / bare numbers; optionally stemmed."""
    out = []
    for t in tokenize(text):
        if len(t) < min_len or t in STOPWORDS or t.isdigit():
            continue
        out.append(stem(t) if do_stem else t)
    return out


def truncate(text: str, n: int = 300) -> str:
    """Shorten text to n characters, adding an ellipsis."""
    text = " ".join(text.split())
    return text if len(text) <= n else text[: max(0, n - 1)].rstrip() + "…"


def sha256_hex(s: str) -> str:
    """SHA-256 hex digest of a string."""
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()


def fingerprint(text: str) -> str:
    """Case/whitespace-insensitive fingerprint used for duplicate detection."""
    norm = " ".join(text.lower().split())
    return hashlib.sha256(norm.encode("utf-8", "replace")).hexdigest()


def slugify(s: str, default: str = "item") -> str:
    """Filesystem/ID-safe slug."""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-._")
    return s[:80] or default


def jdumps(obj: Any, indent: Optional[int] = 2) -> str:
    """JSON dump that never fails on odd types and keeps unicode."""
    return json.dumps(obj, ensure_ascii=False, indent=indent, default=str)


def bar(value: float, maximum: float, width: int = 30) -> str:
    """Unicode bar for text/markdown charts."""
    if maximum <= 0 or value <= 0:
        return ""
    return "█" * max(1, int(round(width * value / maximum)))


def decode_bytes(raw: bytes, forced: Optional[str] = None) -> Tuple[str, str]:
    """Decode bytes to str, detecting the encoding where practical."""
    if forced:
        try:
            return raw.decode(forced), forced
        except (LookupError, UnicodeDecodeError) as exc:
            raise IngestError(f"Cannot decode file as {forced!r}: {exc}") from exc
    for bom, name in ((codecs.BOM_UTF32_LE, "utf-32"), (codecs.BOM_UTF32_BE, "utf-32"),
                      (codecs.BOM_UTF8, "utf-8-sig"), (codecs.BOM_UTF16_LE, "utf-16"),
                      (codecs.BOM_UTF16_BE, "utf-16")):
        if raw.startswith(bom):
            try:
                return raw.decode(name), name
            except UnicodeDecodeError:
                break
    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        pass
    try:  # optional, purely local
        import chardet  # type: ignore
        det = chardet.detect(raw[:500_000])
        enc = det.get("encoding")
        if enc and (det.get("confidence") or 0) >= 0.6:
            return raw.decode(enc), enc
    except Exception:  # noqa: BLE001 - detection is best-effort
        pass
    try:
        return raw.decode("cp1252"), "cp1252"
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace"), "latin-1"


# --------------------------------------------------------------------------
# 1. Date utilities
# --------------------------------------------------------------------------
_UTC = dt.timezone.utc
_DATE_FORMATS = (
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M", "%Y/%m/%d", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y",
    "%B %d, %Y %H:%M:%S", "%B %d, %Y %H:%M", "%B %d, %Y", "%b %d, %Y %H:%M",
    "%b %d, %Y", "%d %B %Y %H:%M", "%d %B %Y", "%d %b %Y %H:%M", "%d %b %Y",
    "%a, %d %b %Y %H:%M:%S %z", "%a, %d %b %Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f",
    "%b %d %Y", "%B %d %Y", "%d %B, %Y",
)
_SLASH_RE = re.compile(
    r"^(\d{1,2})/(\d{1,2})/(\d{2,4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$")
_MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_name) if m}
_MONTHS.update({m.lower(): i for i, m in enumerate(calendar.month_abbr) if m})
_MONTHS.update({"janvier": 1, "février": 2, "fevrier": 2, "mars": 3, "avril": 4, "mai": 5,
                "juin": 6, "juillet": 7, "août": 8, "aout": 8, "septembre": 9,
                "octobre": 10, "novembre": 11, "décembre": 12, "decembre": 12})


def _from_epoch(v: float) -> Optional[dt.datetime]:
    a = abs(v)
    if a > 1e17:
        v /= 1e9
    elif a > 1e14:
        v /= 1e6
    elif a > 1e11:
        v /= 1e3
    try:
        return dt.datetime.fromtimestamp(v, tz=_UTC)
    except (OverflowError, OSError, ValueError):
        return None


def _parse_date_string(s: str, dayfirst: bool) -> Optional[dt.datetime]:
    s = re.sub(r"\s*\(?(?:UTC|GMT)\)?$", "", s.strip())
    try:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00").replace("z", "+00:00"))
    except ValueError:
        pass
    m = _SLASH_RE.match(s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if a > 12:
            day, mon = a, b
        elif b > 12:
            mon, day = a, b
        else:
            day, mon = (a, b) if dayfirst else (b, a)
        hh, mi, ss = (int(m.group(i) or 0) for i in (4, 5, 6))
        try:
            return dt.datetime(y, mon, day, hh, mi, ss)
        except ValueError:
            return None
    for fmt in _DATE_FORMATS:
        try:
            return dt.datetime.strptime(s, fmt)
        except ValueError:
            continue
    m2 = re.match(r"^(\d{1,2})\s+([A-Za-zéûà]+)\.?,?\s+(\d{4})$", s)
    if m2 and m2.group(2).lower() in _MONTHS:
        try:
            return dt.datetime(int(m2.group(3)), _MONTHS[m2.group(2).lower()], int(m2.group(1)))
        except ValueError:
            return None
    return None


def parse_timestamp(value: Any, dayfirst: Optional[bool] = None) -> Optional[dt.datetime]:
    """Parse many timestamp shapes into an aware UTC datetime (or None).

    Naive timestamps are assumed to be UTC. Epoch seconds/ms/us are detected.
    """
    if value is None or isinstance(value, bool):
        return None
    if dayfirst is None:
        dayfirst = DATE_DAYFIRST
    d: Optional[dt.datetime]
    if isinstance(value, dt.datetime):
        d = value
    elif isinstance(value, (int, float)):
        d = _from_epoch(float(value))
    else:
        s = str(value).strip()
        if not s:
            return None
        if re.fullmatch(r"-?\d+(?:\.\d+)?", s):
            if len(s) == 8 and s.isdigit() and 1900 <= int(s[:4]) <= 2200 and 1 <= int(s[4:6]) <= 12:
                try:
                    d = dt.datetime(int(s[:4]), int(s[4:6]), int(s[6:8]))
                except ValueError:
                    d = None
            else:
                d = _from_epoch(float(s))
        else:
            d = _parse_date_string(s, dayfirst)
    if d is None:
        return None
    d = d.replace(tzinfo=_UTC) if d.tzinfo is None else d.astimezone(_UTC)
    if not (1900 <= d.year <= 2200):
        return None
    return d


def to_iso(d: dt.datetime) -> str:
    """Canonical UTC timestamp format used in the database."""
    return d.astimezone(_UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def iso_or_none(value: Any) -> Optional[str]:
    """parse_timestamp + to_iso in one step."""
    d = parse_timestamp(value)
    return to_iso(d) if d else None


def period_bounds(s: str) -> Tuple[str, str]:
    """Return inclusive (start, end) ISO bounds for 'YYYY', 'YYYY-MM', a date, or an instant."""
    s = s.strip()
    m = re.fullmatch(r"(\d{4})", s)
    if m:
        y = int(m.group(1))
        return f"{y:04d}-01-01T00:00:00Z", f"{y:04d}-12-31T23:59:59Z"
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", s)
    if m:
        y, mo = int(m.group(1)), int(m.group(2))
        if not 1 <= mo <= 12:
            raise ValidationError(f"Invalid month in period {s!r}")
        last = calendar.monthrange(y, mo)[1]
        return f"{y:04d}-{mo:02d}-01T00:00:00Z", f"{y:04d}-{mo:02d}-{last:02d}T23:59:59Z"
    d = parse_timestamp(s, dayfirst=False)
    if d is None:
        raise ValidationError(f"Cannot understand date/period {s!r}. Use YYYY, YYYY-MM, YYYY-MM-DD or ISO.")
    iso = to_iso(d)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return iso[:10] + "T00:00:00Z", iso[:10] + "T23:59:59Z"
    return iso, iso


def iso_week(date_str: str) -> str:
    """'YYYY-Www' ISO week label for a YYYY-MM-DD string."""
    d = dt.date.fromisoformat(date_str[:10])
    y, w, _ = d.isocalendar()
    return f"{y}-W{w:02d}"


def fmt_table(rows: Sequence[Sequence[Any]], headers: Sequence[str]) -> str:
    """Plain-text aligned table."""
    cells = [[str(c) for c in r] for r in rows]
    widths = [len(h) for h in headers]
    for r in cells:
        for i, c in enumerate(r):
            widths[i] = min(max(widths[i], len(c)), 60)
    line = "  ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    out = [line, "  ".join("-" * w for w in widths)]
    for r in cells:
        out.append("  ".join(truncate(c, widths[i]).ljust(widths[i]) for i, c in enumerate(r)))
    return "\n".join(out)



# ==========================================================================
# 2. INGESTION: record model, normaliser, readers, importer
# ==========================================================================
ROLE_MAP = {
    "user": "user", "human": "user", "me": "user", "you": "user", "customer": "user",
    "client": "user", "utilisateur": "user", "moi": "user", "person": "user",
    "assistant": "assistant", "ai": "assistant", "bot": "assistant", "claude": "assistant",
    "chatgpt": "assistant", "gpt": "assistant", "model": "assistant", "gemini": "assistant",
    "system": "system", "tool": "tool", "function": "tool", "note": "note",
}

KEY_ALIASES: Dict[str, Tuple[str, ...]] = {
    "content": ("content", "text", "message", "body", "msg", "utterance", "parts", "prompt",
                "response", "completion", "note", "value", "transcript"),
    "role": ("role", "author", "sender", "from", "speaker", "author_role", "who", "user_role"),
    "ts": ("timestamp", "ts", "time", "datetime", "date", "created_at", "create_time", "created",
           "sent_at", "date_time", "when", "creation_date", "updated_at", "message_date"),
    "conversation_id": ("conversation_id", "conversation", "conv_id", "thread_id", "thread",
                        "chat_id", "session_id", "session", "conversation_uuid", "convo_id"),
    "message_id": ("message_id", "msg_id", "id", "uuid", "msgid"),
    "source": ("source", "origin", "app", "platform", "channel", "file"),
    "topic": ("topic", "subject", "conversation_title", "title", "name"),
    "category": ("category", "type_of", "kind", "area"),
    "project": ("project", "project_name"),
    "tags": ("tags", "labels", "keywords", "tag"),
    "related": ("related", "related_ids", "related_records", "related_to"),
    "parent": ("parent_id", "reply_to", "in_reply_to", "parent_message_id", "parent_uuid"),
}
CONTAINER_KEYS = ("messages", "chat_messages", "turns", "history", "entries", "conversation_messages",
                  "dialogue", "exchanges")
LIST_KEYS = ("conversations", "chats", "threads", "items", "data", "records", "sessions", "results")
_INJECTION_RE = re.compile(
    r"(ignore|disregard|forget|override)\s+(all\s+|any\s+|the\s+|your\s+)?(previous|prior|above|earlier|system)\s+"
    r"(instructions?|prompts?|rules?|messages?)|you\s+are\s+now\s+(?:a|an|in)\b|reveal\s+(?:your\s+)?system\s+prompt|"
    r"<\s*/?\s*(?:system|instructions?)\s*>|(?:run|execute)\s+(?:the\s+following|this)\s+(?:shell\s+)?(?:command|script|code)|"
    r"\bsudo\s+rm\s+-rf\b|\bcurl\s+[^|\n]+\|\s*(?:ba)?sh\b", re.I)


@dataclass
class Record:
    """Normalised memory record (one message / note)."""
    id: str
    conversation_id: str
    message_id: Optional[str]
    ts: Optional[str]
    role: str
    content: str
    source: str = ""
    topic: str = ""
    category: str = ""
    project: str = ""
    tags: List[str] = field(default_factory=list)
    related: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    seq: int = 0
    flags: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    dupkey: Optional[str] = None


@dataclass
class ImportOptions:
    """User-supplied defaults and switches for an import run."""
    source: str = ""
    project: str = ""
    category: str = ""
    topic: str = ""
    tags: List[str] = field(default_factory=list)
    conversation_id: str = ""
    encoding: Optional[str] = None
    fmt: Optional[str] = None
    dayfirst: bool = False
    recursive: bool = False
    force: bool = False
    dry_run: bool = False
    default_role: str = "note"


@dataclass
class ImportResult:
    """Outcome of importing one file."""
    file: str
    status: str = "ok"          # ok | skipped_unchanged | failed | dry_run
    fmt: str = ""
    encoding: str = ""
    total: int = 0
    inserted: int = 0
    duplicates: int = 0
    invalid: int = 0
    flagged: int = 0
    conversations: int = 0
    undated: int = 0
    errors: List[str] = field(default_factory=list)
    import_id: Optional[int] = None
    message: str = ""

    def as_dict(self) -> Dict[str, Any]:
        """Plain dict (for JSON output)."""
        return dict(self.__dict__)


def norm_role(v: Any) -> str:
    """Normalise a role/author value ('Human' -> 'user')."""
    if isinstance(v, dict):
        v = v.get("role") or v.get("name") or v.get("id") or ""
    s = str(v or "").strip().lower()
    if not s:
        return ""
    return ROLE_MAP.get(s, s[:40])


def split_list(v: Any) -> List[str]:
    """Turn a list or delimited string into a clean unique list of tags."""
    if v is None:
        return []
    if isinstance(v, str):
        s = v.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                v = json.loads(s)
            except ValueError:
                v = re.split(r"[;,|]", s.strip("[]"))
        else:
            v = re.split(r"[;,|]", s)
    if not isinstance(v, (list, tuple, set)):
        v = [v]
    out: List[str] = []
    for x in v:
        t = str(x).strip().strip("'\"#").strip()
        if t and t.lower() not in {o.lower() for o in out}:
            out.append(t[:80])
    return out


def extract_text(v: Any, depth: int = 0) -> str:
    """Extract readable text from strings / nested content-part structures."""
    if v is None or depth > 6:
        return ""
    if isinstance(v, str):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    if isinstance(v, list):
        return "\n".join(t for t in (extract_text(x, depth + 1) for x in v) if t)
    if isinstance(v, dict):
        typ = str(v.get("type", "")).lower()
        if typ in {"image", "image_url", "tool_use", "thinking", "redacted_thinking"} and "text" not in v:
            return ""
        for k in ("text", "content", "parts", "value", "result"):
            if k in v:
                t = extract_text(v[k], depth + 1)
                if t:
                    return t
    return ""


def _pick(raw: Dict[str, Any], key: str) -> Any:
    low = {str(k).strip().lower(): v for k, v in raw.items()}
    for a in KEY_ALIASES[key]:
        if a in low and low[a] not in (None, ""):
            return low[a]
    return None


class Normalizer:
    """Turns raw dictionaries into validated :class:`Record` objects."""

    def __init__(self, opts: ImportOptions, filename: str):
        self.opts = opts
        self.filename = filename
        self.source_default = opts.source or Path(filename).name

    def normalize(self, raw: Dict[str, Any], conv_default: str, seq: int,
                  conv_meta: Optional[Dict[str, Any]] = None) -> Record:
        """Validate and normalise one raw message dict. Raises ValidationError."""
        if not isinstance(raw, dict):
            raise ValidationError(f"record is not an object (got {type(raw).__name__})")
        conv_meta = conv_meta or {}
        content = extract_text(_pick(raw, "content"))
        content = clean_text(content)
        if not content:
            raise ValidationError("empty message content")
        flags: List[str] = []
        if len(content) > MAX_RECORD_CHARS:
            content = content[:MAX_RECORD_CHARS]
            flags.append("truncated")
        if _INJECTION_RE.search(content):
            flags.append("possible_injection")
        role = norm_role(_pick(raw, "role")) or self.opts.default_role
        raw_ts = _pick(raw, "ts")
        if raw_ts is None:
            raw_ts = conv_meta.get("_ts")
        ts_dt = parse_timestamp(raw_ts, dayfirst=self.opts.dayfirst)
        meta: Dict[str, Any] = {}
        if raw_ts is not None and ts_dt is None:
            flags.append("bad_timestamp")
            meta["raw_timestamp"] = str(raw_ts)[:100]
        ts = to_iso(ts_dt) if ts_dt else None
        if ts is None:
            flags.append("undated")
        precise = bool(ts_dt and (ts_dt.hour or ts_dt.minute or ts_dt.second))
        conv = str(_pick(raw, "conversation_id") or conv_meta.get("id") or self.opts.conversation_id
                   or conv_default).strip()[:200] or conv_default
        mid = _pick(raw, "message_id")
        mid_s = str(mid).strip()[:200] if mid is not None else None
        topic = str(_pick(raw, "topic") or conv_meta.get("title") or self.opts.topic or "").strip()[:300]
        category = str(_pick(raw, "category") or conv_meta.get("category") or self.opts.category or "").strip()[:120]
        project = str(_pick(raw, "project") or conv_meta.get("project") or self.opts.project or "").strip()[:200]
        source = str(_pick(raw, "source") or conv_meta.get("source") or self.source_default).strip()[:300]
        tags = split_list(_pick(raw, "tags"))
        for t in list(split_list(conv_meta.get("tags"))) + list(self.opts.tags):
            if t.lower() not in {x.lower() for x in tags}:
                tags.append(t)
        related = split_list(_pick(raw, "related"))
        parent = _pick(raw, "parent")
        parent_s = str(parent).strip()[:200] if parent not in (None, "") else None
        known = {a for k in KEY_ALIASES.values() for a in k}
        for k, v in raw.items():
            kl = str(k).strip().lower()
            if kl not in known and isinstance(v, (str, int, float, bool)) and len(meta) < 25:
                meta[str(k)[:60]] = v if not isinstance(v, str) else v[:500]
        fp = fingerprint(content)
        if mid_s is None and not ts:
            key = f"{conv}|{seq}|{role}|{fp}"
        else:
            key = f"{conv}|{mid_s or ''}|{role}|{ts or ''}|{fp}"
        rid = "mi_" + sha256_hex(key)[:20]
        dupkey = sha256_hex(f"{role}|{ts}|{fp}")[:24] if precise and len(content) >= 20 else None
        return Record(id=rid, conversation_id=conv, message_id=mid_s, ts=ts, role=role, content=content,
                      source=source, topic=topic, category=category, project=project, tags=tags,
                      related=related, metadata=meta, seq=seq, flags=flags, parent=parent_s, dupkey=dupkey)


# ---- structure walkers -----------------------------------------------------
def _chatgpt_messages(conv: Dict[str, Any]) -> List[Dict[str, Any]]:
    mapping = conv.get("mapping") or {}
    order: List[str] = []
    cur = conv.get("current_node")
    if cur and cur in mapping:
        seen: Set[str] = set()
        while cur and cur in mapping and cur not in seen:
            seen.add(cur)
            order.append(cur)
            cur = mapping[cur].get("parent")
        order.reverse()
    else:
        order = sorted(mapping, key=lambda k: ((mapping[k].get("message") or {}).get("create_time") or 0))
    msgs: List[Dict[str, Any]] = []
    for nid in order:
        m = (mapping.get(nid) or {}).get("message")
        if not m:
            continue
        meta = m.get("metadata") or {}
        if meta.get("is_visually_hidden_from_conversation"):
            continue
        role = (m.get("author") or {}).get("role", "")
        if role == "system" and not extract_text((m.get("content") or {}).get("parts")):
            continue
        c = m.get("content") or {}
        text = extract_text(c.get("parts")) or extract_text(c.get("text"))
        msgs.append({"id": m.get("id") or nid, "role": role, "content": text,
                     "ts": m.get("create_time"), "parent": mapping[nid].get("parent")})
    return msgs


def _is_conv_dict(d: Dict[str, Any]) -> bool:
    return isinstance(d, dict) and ("mapping" in d or any(isinstance(d.get(k), list) for k in CONTAINER_KEYS))


def iter_conversations(obj: Any, depth: int = 0) -> Iterator[Tuple[Dict[str, Any], List[Dict[str, Any]]]]:
    """Yield (conversation_meta, messages) pairs from many JSON export layouts.

    Flat message lists are yielded as ({}, messages) and grouped by conversation id later.
    """
    if depth > 4:
        return
    if isinstance(obj, list):
        dicts = [x for x in obj if isinstance(x, dict)]
        if dicts and all(_is_conv_dict(x) for x in dicts):
            for c in dicts:
                yield from iter_conversations(c, depth + 1)
        elif dicts:
            yield {}, dicts
        return
    if not isinstance(obj, dict):
        return
    if "mapping" in obj and isinstance(obj["mapping"], dict):
        meta = {"id": obj.get("conversation_id") or obj.get("id"), "title": obj.get("title"),
                "_ts": obj.get("create_time")}
        yield meta, _chatgpt_messages(obj)
        return
    for k in CONTAINER_KEYS:
        if isinstance(obj.get(k), list):
            meta = {"id": obj.get("uuid") or obj.get("id") or obj.get("conversation_id"),
                    "title": obj.get("name") or obj.get("title") or obj.get("subject") or obj.get("topic"),
                    "_ts": obj.get("created_at") or obj.get("create_time") or obj.get("date"),
                    "project": obj.get("project"), "category": obj.get("category"),
                    "tags": obj.get("tags"), "source": obj.get("source")}
            msgs = []
            for m in obj[k]:
                if isinstance(m, dict):
                    m = dict(m)
                    if "text" not in m and "content" not in m and isinstance(m.get("content"), list):
                        pass
                    msgs.append(m)
            yield meta, msgs
            return
    for k in LIST_KEYS:
        if isinstance(obj.get(k), (list, dict)) and k in obj:
            inner = obj[k]
            if isinstance(inner, dict):
                inner = list(inner.values())
            yield from iter_conversations(inner, depth + 1)
            return
    if _pick(obj, "content") is not None:
        yield {}, [obj]


def _claude_fix(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Claude exports have both 'text' and structured 'content'; prefer non-empty text."""
    out = []
    for m in msgs:
        m = dict(m)
        if "sender" in m and isinstance(m.get("content"), list) and not m.get("text"):
            m["text"] = extract_text(m["content"])
        out.append(m)
    return out


# ---- text / markdown -------------------------------------------------------
_SPK_RE = re.compile(
    r"^\s*(?:\[(?P<ts>[^\]]{6,40})\]\s*)?(?:(?:#{1,6}|>|[-*])\s*)?\*{0,2}"
    r"(?P<spk>user|human|you|me|assistant|ai|claude|chatgpt|gpt|bot|system|moi|utilisateur|[A-Z][\w.\- ]{0,24}?)"
    r"\*{0,2}\s*[:：]\*{0,2}\s*(?P<rest>.*)$", re.I)
_HEADING_SPK_RE = re.compile(
    r"^\s*#{1,6}\s*\*{0,2}(user|human|you|me|assistant|ai|claude|chatgpt|system)\*{0,2}\s*:?\s*$", re.I)
_TS_LINE_RE = re.compile(r"^\s*\[(?P<ts>[^\]]{6,40})\]\s*(?P<spk>[^:\]]{1,30}?)\s*:\s*(?P<rest>.*)$")
_FILEDATE_RE = re.compile(r"(\d{4}[-_.]\d{2}[-_.]\d{2})")
_KNOWN_SPK = set(ROLE_MAP)


def parse_front_matter(text: str) -> Tuple[Dict[str, Any], str]:
    """Parse a minimal YAML-like front matter block (no YAML library, no code execution)."""
    if not text.startswith("---"):
        return {}, text
    m = re.match(r"^---\s*\n(.*?)\n(?:---|\.\.\.)\s*(?:\n|$)", text, re.S)
    if not m:
        return {}, text
    meta: Dict[str, Any] = {}
    for line in m.group(1).split("\n"):
        mm = re.match(r"^([A-Za-z_][\w\- ]*):\s*(.*)$", line)
        if mm:
            v = mm.group(2).strip().strip("'\"")
            meta[mm.group(1).strip().lower().replace(" ", "_")] = v
    return meta, text[m.end():]


def parse_text_document(text: str, filename: str, opts: ImportOptions) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Parse TXT/Markdown into (conversation_meta, messages).

    Transcript mode is used when >=2 speaker lines are found; otherwise the document is split
    into note records by dated/regular headings or paragraph chunks.
    """
    fm, body = parse_front_matter(text)
    stem = Path(filename).stem
    meta: Dict[str, Any] = {"id": fm.get("conversation_id") or opts.conversation_id or slugify(stem, "document"),
                            "title": fm.get("title") or fm.get("topic"), "project": fm.get("project"),
                            "category": fm.get("category"), "tags": fm.get("tags"), "source": fm.get("source")}
    doc_date = fm.get("date") or fm.get("created") or fm.get("created_at")
    if not doc_date:
        fd = _FILEDATE_RE.search(Path(filename).name)
        if fd:
            doc_date = fd.group(1).replace("_", "-").replace(".", "-")
    meta["_ts"] = doc_date
    lines = body.split("\n")
    # Transcript detection
    n_spk = 0
    for ln in lines:
        m = _SPK_RE.match(ln)
        hm = _HEADING_SPK_RE.match(ln)
        if hm or (m and (m.group("spk").lower() in _KNOWN_SPK or (m.group("ts") and m.group("rest")))):
            n_spk += 1
    messages: List[Dict[str, Any]] = []
    if n_spk >= 2:
        cur: Optional[Dict[str, Any]] = None
        buf: List[str] = []

        def flush() -> None:
            nonlocal cur, buf
            if cur is not None:
                cur["content"] = "\n".join(buf).strip()
                if cur["content"]:
                    messages.append(cur)
            cur, buf = None, []

        for ln in lines:
            hm = _HEADING_SPK_RE.match(ln)
            m = _SPK_RE.match(ln)
            if hm:
                flush()
                cur = {"role": hm.group(1), "ts": None}
                continue
            if m and (m.group("spk").lower() in _KNOWN_SPK or (m.group("ts") and m.group("rest"))):
                flush()
                spk = m.group("spk").strip()
                cur = {"role": spk, "ts": m.group("ts")}
                if spk.lower() not in _KNOWN_SPK:
                    cur["author"] = spk
                buf = [m.group("rest")]
                continue
            if cur is not None:
                buf.append(ln)
        flush()
        return meta, messages
    # Document mode: split by headings
    sections: List[Tuple[str, List[str]]] = []
    head, cur_lines = (fm.get("title") or ""), []  # type: str, List[str]
    for ln in lines:
        hm = re.match(r"^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$", ln)
        if hm:
            if cur_lines and "".join(cur_lines).strip():
                sections.append((head, cur_lines))
            head, cur_lines = hm.group(1).strip(), []
        else:
            cur_lines.append(ln)
    if cur_lines and "".join(cur_lines).strip():
        sections.append((head, cur_lines))
    for head, sl in sections:
        sec_ts = None
        topic = head
        if head and parse_timestamp(head, dayfirst=opts.dayfirst) and len(head) <= 40:
            sec_ts, topic = head, ""
        paras = [p.strip() for p in re.split(r"\n\s*\n", "\n".join(sl)) if p.strip()]
        chunk: List[str] = []
        size = 0
        for p in paras + [None]:  # type: ignore[list-item]
            if p is None or (chunk and size + len(p) > 1500):
                if chunk:
                    m = {"role": opts.default_role, "content": "\n\n".join(chunk)}
                    if sec_ts:
                        m["ts"] = sec_ts
                    if topic:
                        m["topic"] = topic
                    messages.append(m)
                chunk, size = [], 0
            if p is not None:
                chunk.append(p)
                size += len(p)
    return meta, messages


def _parse_jsonl(raw_text: str, errors: List[str]) -> List[Any]:
    """Parse JSON Lines; invalid lines are reported, not fatal."""
    out: List[Any] = []
    for i, ln in enumerate(raw_text.split("\n"), 1):
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except ValueError as exc:
            errors.append(f"line {i}: invalid JSON ({exc.msg})")
    return out


def _read_csv_rows(text: str, errors: List[str]) -> List[Dict[str, Any]]:
    """Read CSV/TSV with sniffing; row errors are reported and skipped."""
    try:
        csv.field_size_limit(10_000_000)
    except OverflowError:
        pass
    sample = text[:20000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rdr = csv.DictReader(io.StringIO(text, newline=""), dialect=dialect)
    if not rdr.fieldnames:
        raise IngestError("CSV has no header row")
    rows: List[Dict[str, Any]] = []
    try:
        for i, row in enumerate(rdr, start=2):
            if None in row:  # extra fields
                row.pop(None, None)
            if all((v or "").strip() == "" for v in row.values()):
                continue
            rows.append({k.strip(): (v.strip() if isinstance(v, str) else v) for k, v in row.items() if k})
    except csv.Error as exc:
        errors.append(f"CSV parse error near line {rdr.line_num}: {exc}")
    return rows


def _messages_from_json(obj: Any, stem: str, opts: ImportOptions, norm: Normalizer,
                        errors: List[str]) -> List[Record]:
    """Normalise every message found in a decoded JSON object."""
    recs: List[Record] = []
    seq = 0
    for ci, (meta, msgs) in enumerate(iter_conversations(obj)):
        meta = dict(meta or {})
        if meta.get("id") is None or str(meta.get("id")).strip() == "":
            meta["id"] = None
        conv_default = f"{slugify(stem, 'import')}-c{ci + 1}" if meta.get("id") is None else slugify(stem)
        for m in msgs:
            seq += 1
            try:
                if isinstance(m, dict) and "sender" in m and not m.get("text") and isinstance(m.get("content"), list):
                    m = dict(m)
                    m["text"] = extract_text(m["content"])
                recs.append(norm.normalize(m, conv_default, seq, meta))
            except ValidationError as exc:
                errors.append(f"message #{seq}: {exc}")
    return recs


def parse_bytes(name: str, raw: bytes, opts: ImportOptions) -> Tuple[List[Record], List[str], str, str]:
    """Parse one file's bytes into records. Returns (records, errors, format, encoding)."""
    ext = Path(name).suffix.lower()
    fmt = (opts.fmt or ext.lstrip(".")).lower()
    if fmt == "ndjson":
        fmt = "jsonl"
    if fmt == "markdown":
        fmt = "md"
    if fmt == "tsv":
        fmt = "csv"
    errors: List[str] = []
    stem = Path(name).stem
    norm = Normalizer(opts, name)
    if fmt == "zip":
        return _parse_zip(name, raw, opts, errors)
    if fmt not in {"json", "jsonl", "csv", "txt", "md"}:
        raise IngestError(f"Unsupported format {fmt!r} for {name}. Supported: {', '.join(sorted(SUPPORTED_EXTS))}")
    if len(raw) > MAX_FILE_BYTES:
        raise IngestError(f"{name} is larger than the {MAX_FILE_BYTES // 1024 ** 3} GB limit")
    text, enc = decode_bytes(raw, opts.encoding)
    text = text.lstrip("﻿")
    if fmt == "json":
        if len(raw) > MAX_JSON_BYTES:
            raise IngestError(f"{name} is too large for JSON parsing; convert to JSONL")
        try:
            obj = json.loads(text)
        except ValueError as exc:
            raise IngestError(f"{name}: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc
        recs = _messages_from_json(obj, stem, opts, norm, errors)
    elif fmt == "jsonl":
        objs = _parse_jsonl(text, errors)
        recs = _messages_from_json(objs, stem, opts, norm, errors)
    elif fmt == "csv":
        rows = _read_csv_rows(text, errors)
        recs = []
        for i, row in enumerate(rows, 1):
            low_keys = {k.strip().lower() for k in row}
            if not low_keys & set(KEY_ALIASES["content"]):
                # No explicit text column: the row itself is the record (all non-empty fields, labelled)
                row = {**row, "content": "; ".join(f"{k}: {v}" for k, v in row.items() if v not in (None, ""))}
            try:
                recs.append(norm.normalize(row, slugify(stem), i))
            except ValidationError as exc:
                errors.append(f"row {i}: {exc}")
    else:  # txt / md
        meta, msgs = parse_text_document(text, name, opts)
        conv_default = slugify(stem)
        recs = []
        for i, m in enumerate(msgs, 1):
            try:
                rec_raw = dict(m)
                if "author" in rec_raw:
                    rec_raw.setdefault("source", rec_raw.get("author"))
                recs.append(norm.normalize(rec_raw, conv_default, i, meta))
            except ValidationError as exc:
                errors.append(f"message #{i}: {exc}")
    return recs, errors, fmt, enc


def _parse_zip(name: str, raw: bytes, opts: ImportOptions, errors: List[str]) -> Tuple[List[Record], List[str], str, str]:
    """Read supported members of a ZIP archive in memory (never extracted to disk)."""
    recs: List[Record] = []
    encs: Set[str] = set()
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile as exc:
        raise IngestError(f"{name} is not a valid ZIP archive: {exc}") from exc
    members = [i for i in zf.infolist() if not i.is_dir()]
    if len(members) > MAX_ZIP_MEMBERS:
        raise IngestError(f"ZIP has {len(members)} members (limit {MAX_ZIP_MEMBERS})")
    total = 0
    for info in members:
        pname = info.filename
        if pname.startswith(("/", "\\")) or ".." in Path(pname).parts:
            errors.append(f"skipped unsafe path in archive: {pname!r}")
            continue
        ext = Path(pname).suffix.lower()
        if ext not in SUPPORTED_EXTS - {".zip"}:
            continue
        if info.file_size > MAX_ZIP_MEMBER_BYTES:
            errors.append(f"skipped oversized member {pname}")
            continue
        total += info.file_size
        if total > MAX_ZIP_TOTAL_BYTES:
            errors.append("ZIP total uncompressed size limit reached; remaining members skipped")
            break
        data = zf.read(info)
        sub_opts = ImportOptions(**{**opts.__dict__, "fmt": None})
        try:
            r, e, _, enc = parse_bytes(pname, data, sub_opts)
            recs.extend(r)
            errors.extend(f"{pname}: {x}" for x in e)
            encs.add(enc)
        except IngestError as exc:
            errors.append(str(exc))
    return recs, errors, "zip", ",".join(sorted(encs))


# ==========================================================================
# 3. PERSISTENT DATABASE
# ==========================================================================
SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS imports (
    import_id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT NOT NULL,
    file_sha256 TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    fmt TEXT, encoding TEXT,
    imported_at TEXT NOT NULL,
    total INTEGER, inserted INTEGER, duplicates INTEGER, invalid INTEGER,
    status TEXT NOT NULL,
    notes TEXT
);
CREATE INDEX IF NOT EXISTS ix_imports_file ON imports(file_path, file_sha256);
CREATE TABLE IF NOT EXISTS records (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    message_id TEXT,
    ts TEXT,
    year TEXT,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    content_lc TEXT NOT NULL,
    source TEXT, topic TEXT, category TEXT, project TEXT,
    tags TEXT, tags_text TEXT,
    related TEXT, parent TEXT,
    metadata TEXT, flags TEXT,
    seq INTEGER, dupkey TEXT,
    import_id INTEGER REFERENCES imports(import_id),
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_rec_ts ON records(ts);
CREATE INDEX IF NOT EXISTS ix_rec_conv ON records(conversation_id, seq);
CREATE INDEX IF NOT EXISTS ix_rec_project ON records(project);
CREATE INDEX IF NOT EXISTS ix_rec_topic ON records(topic);
CREATE INDEX IF NOT EXISTS ix_rec_category ON records(category);
CREATE INDEX IF NOT EXISTS ix_rec_source ON records(source);
CREATE INDEX IF NOT EXISTS ix_rec_role ON records(role);
CREATE INDEX IF NOT EXISTS ix_rec_dupkey ON records(dupkey);
CREATE TABLE IF NOT EXISTS relations (
    src_id TEXT NOT NULL, dst_id TEXT NOT NULL, kind TEXT NOT NULL,
    PRIMARY KEY (src_id, dst_id, kind)
);
CREATE TABLE IF NOT EXISTS projects (
    name TEXT PRIMARY KEY,
    first_seen TEXT, latest TEXT,
    record_count INTEGER DEFAULT 0,
    description TEXT DEFAULT '',
    objective TEXT DEFAULT '',
    updated_at TEXT
);
"""

FTS_SCHEMA = ("CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5("
              "content, topic, tags_text, record_id UNINDEXED, tokenize = 'unicode61 remove_diacritics 2')")


def utc_now_iso() -> str:
    """Current UTC time, ISO format."""
    return dt.datetime.now(_UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def default_db_path() -> Path:
    """Database location: $MEMORY_INTELLIGENCE_HOME/memory.db or ~/.memory_intelligence/memory.db.
    Always outside the Skill package."""
    home = os.environ.get(ENV_HOME)
    base = Path(home).expanduser() if home else Path.home() / ".memory_intelligence"
    return base / "memory.db"


class MemoryDB:
    """Persistent SQLite store with FTS5, transactions, integrity and backup tools."""

    def __init__(self, path: Path, create: bool = True):
        self.path = Path(path).expanduser()
        if not create and not self.path.exists():
            raise NotFoundError(f"Database not found: {self.path}. Run `init` first.")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), timeout=30, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA busy_timeout=30000")
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        self.fts_available = True
        self.init_schema()

    def close(self) -> None:
        """Close the connection."""
        self.conn.close()

    def __enter__(self) -> "MemoryDB":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    @contextlib.contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Atomic write transaction; rolls back on any exception."""
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield self.conn
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise

    def init_schema(self) -> None:
        """Create tables if missing and record the schema version."""
        with self.transaction() as c:
            for stmt in SCHEMA.split(";\n"):
                if stmt.strip():
                    c.execute(stmt)
            try:
                c.execute(FTS_SCHEMA)
            except sqlite3.OperationalError as exc:
                self.fts_available = False
                LOG.info("FTS5 unavailable (%s); falling back to LIKE search", exc)
            c.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
            c.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('created_at', ?)", (utc_now_iso(),))
            c.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('fts_available', ?)",
                      ("1" if self.fts_available else "0"))
        ver = self.get_meta("schema_version")
        if ver != str(SCHEMA_VERSION):
            raise ValidationError(f"Database schema version {ver} is not supported (expected {SCHEMA_VERSION})")

    def get_meta(self, key: str) -> Optional[str]:
        """Read a meta value."""
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def has_fts(self) -> bool:
        """True if the FTS5 table exists."""
        row = self.conn.execute("SELECT 1 FROM sqlite_master WHERE name='records_fts'").fetchone()
        return bool(row)

    # ---- imports --------------------------------------------------------
    def find_import(self, path: str, sha: str) -> Optional[sqlite3.Row]:
        """Previous successful import of the same file content."""
        return self.conn.execute(
            "SELECT * FROM imports WHERE file_path=? AND file_sha256=? AND status='ok' ORDER BY import_id DESC LIMIT 1",
            (path, sha)).fetchone()

    def record_import(self, c: sqlite3.Connection, **kw: Any) -> int:
        """Insert an import-history row and return its id."""
        cur = c.execute(
            "INSERT INTO imports(file_path, file_sha256, file_size, fmt, encoding, imported_at, total, inserted,"
            " duplicates, invalid, status, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (kw["file_path"], kw["file_sha256"], kw["file_size"], kw.get("fmt"), kw.get("encoding"),
             utc_now_iso(), kw.get("total", 0), kw.get("inserted", 0), kw.get("duplicates", 0),
             kw.get("invalid", 0), kw.get("status", "ok"), kw.get("notes")))
        return int(cur.lastrowid)

    def import_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Most recent import runs."""
        rows = self.conn.execute("SELECT * FROM imports ORDER BY import_id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    # ---- records --------------------------------------------------------
    def existing_dupkeys(self) -> Set[str]:
        """All duplicate-detection keys already stored."""
        return {r[0] for r in self.conn.execute("SELECT dupkey FROM records WHERE dupkey IS NOT NULL")}

    def insert_records(self, c: sqlite3.Connection, recs: Sequence[Record], import_id: int) -> Tuple[int, int]:
        """Insert records, skipping ids or duplicate keys already present. Returns (inserted, duplicates)."""
        known = self.existing_dupkeys()
        inserted = dups = 0
        now = utc_now_iso()
        seen_batch: Set[str] = set()
        for r in recs:
            if r.dupkey and (r.dupkey in known or r.dupkey in seen_batch):
                dups += 1
                continue
            if r.dupkey:
                seen_batch.add(r.dupkey)
            tags_text = "|" + "|".join(t.lower() for t in r.tags) + "|" if r.tags else ""
            cur = c.execute(
                "INSERT OR IGNORE INTO records(id, conversation_id, message_id, ts, year, role, content, content_lc,"
                " source, topic, category, project, tags, tags_text, related, parent, metadata, flags, seq, dupkey,"
                " import_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (r.id, r.conversation_id, r.message_id, r.ts, r.ts[:4] if r.ts else None, r.role, r.content,
                 r.content.lower(), r.source, r.topic, r.category, r.project, json.dumps(r.tags, ensure_ascii=False),
                 tags_text, json.dumps(r.related, ensure_ascii=False), r.parent,
                 json.dumps(r.metadata, ensure_ascii=False, default=str), ",".join(r.flags), r.seq, r.dupkey,
                 import_id, now))
            if cur.rowcount == 0:
                dups += 1
                continue
            inserted += 1
            if self.has_fts():
                c.execute("INSERT INTO records_fts(content, topic, tags_text, record_id) VALUES (?,?,?,?)",
                          (r.content, r.topic, tags_text, r.id))
            for dst in r.related:
                c.execute("INSERT OR IGNORE INTO relations(src_id, dst_id, kind) VALUES (?,?,?)", (r.id, dst, "related"))
            if r.parent:
                c.execute("INSERT OR IGNORE INTO relations(src_id, dst_id, kind) VALUES (?,?,?)", (r.id, r.parent, "reply_to"))
            if r.project:
                c.execute(
                    "INSERT INTO projects(name, first_seen, latest, record_count, updated_at) VALUES (?,?,?,1,?)"
                    " ON CONFLICT(name) DO UPDATE SET record_count = record_count + 1,"
                    " first_seen = MIN(COALESCE(first_seen, excluded.first_seen), COALESCE(excluded.first_seen, first_seen)),"
                    " latest = MAX(COALESCE(latest, ''), COALESCE(excluded.latest, '')), updated_at=excluded.updated_at",
                    (r.project, r.ts, r.ts, now))
        return inserted, dups

    def record_count(self) -> int:
        """Total stored records."""
        return int(self.conn.execute("SELECT COUNT(*) FROM records").fetchone()[0])

    def get_record(self, rid: str) -> Optional[Dict[str, Any]]:
        """Single record by id (exact or unique prefix)."""
        row = self.conn.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
        if row is None:
            rows = self.conn.execute("SELECT * FROM records WHERE id LIKE ? LIMIT 2", (rid + "%",)).fetchall()
            if len(rows) == 1:
                row = rows[0]
            elif len(rows) > 1:
                raise ValidationError(f"Record id prefix {rid!r} is ambiguous")
        return row_to_dict(row) if row else None

    # ---- maintenance ----------------------------------------------------
    def integrity(self) -> Dict[str, Any]:
        """Run SQLite integrity and consistency checks."""
        res: Dict[str, Any] = {}
        res["sqlite_integrity"] = self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        res["foreign_key_violations"] = len(self.conn.execute("PRAGMA foreign_key_check").fetchall())
        res["records"] = self.record_count()
        if self.has_fts():
            res["fts_rows"] = int(self.conn.execute("SELECT COUNT(*) FROM records_fts").fetchone()[0])
            res["fts_in_sync"] = res["fts_rows"] == res["records"]
        res["ok"] = (res["sqlite_integrity"] == "ok" and res["foreign_key_violations"] == 0
                     and res.get("fts_in_sync", True))
        return res

    def optimize(self) -> Dict[str, Any]:
        """ANALYZE, FTS merge, PRAGMA optimize and VACUUM."""
        before = self.path.stat().st_size if self.path.exists() else 0
        self.conn.execute("PRAGMA optimize")
        if self.has_fts():
            self.conn.execute("INSERT INTO records_fts(records_fts) VALUES('optimize')")
        self.conn.execute("ANALYZE")
        self.conn.execute("VACUUM")
        after = self.path.stat().st_size if self.path.exists() else 0
        return {"bytes_before": before, "bytes_after": after}

    def backup(self, dest: Path) -> Dict[str, Any]:
        """Consistent online backup via SQLite's backup API, then verified."""
        dest = Path(dest).expanduser()
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            raise ConfirmationRequired(f"{dest} already exists; choose another name")
        tmp = dest.with_suffix(dest.suffix + ".part")
        target = sqlite3.connect(str(tmp))
        try:
            self.conn.backup(target)
        finally:
            target.close()
        check = sqlite3.connect(str(tmp))
        try:
            ok = check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            n = check.execute("SELECT COUNT(*) FROM records").fetchone()[0]
        finally:
            check.close()
        if not ok:
            tmp.unlink(missing_ok=True)
            raise MemoryEngineError("Backup verification failed; backup discarded")
        os.replace(tmp, dest)
        return {"path": str(dest), "bytes": dest.stat().st_size, "records": int(n), "verified": True}

    def restore(self, src: Path, confirm: bool, safety_dir: Optional[Path] = None) -> Dict[str, Any]:
        """Replace the current database with a backup. Requires confirm=True; makes a safety backup first."""
        if not confirm:
            raise ConfirmationRequired("Restore replaces all data. Re-run with --yes to confirm.")
        src = Path(src).expanduser()
        if not src.exists():
            raise NotFoundError(f"Backup not found: {src}")
        probe = sqlite3.connect(str(src))
        try:
            ok = probe.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            ver = None
            try:
                ver = probe.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
            except sqlite3.DatabaseError:
                pass
        except sqlite3.DatabaseError as exc:
            raise IngestError(f"{src} is not a valid SQLite database: {exc}") from exc
        finally:
            probe.close()
        if not ok or ver != str(SCHEMA_VERSION):
            raise ValidationError("Backup failed integrity check or has an unsupported schema version")
        safety = (safety_dir or self.path.parent) / f"pre-restore-{time.strftime('%Y%m%d-%H%M%S')}.db"
        safety_info = self.backup(safety)
        source = sqlite3.connect(str(src))
        try:
            source.backup(self.conn)
        finally:
            source.close()
        self.conn.execute("PRAGMA optimize")
        return {"restored_from": str(src), "safety_backup": safety_info["path"], "records": self.record_count()}


def row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """sqlite Row -> plain dict with JSON fields decoded."""
    d = dict(row)
    for k in ("tags", "related", "metadata"):
        if k in d and isinstance(d[k], str):
            try:
                d[k] = json.loads(d[k])
            except ValueError:
                pass
    d.pop("content_lc", None)
    d.pop("tags_text", None)
    d.pop("dupkey", None)
    if "flags" in d:
        d["flags"] = [f for f in (d["flags"] or "").split(",") if f]
    return d


class Importer:
    """Imports files into the database with duplicate detection and import history."""

    def __init__(self, db: MemoryDB):
        self.db = db

    def import_path(self, path: Path, opts: ImportOptions) -> List[ImportResult]:
        """Import one file, or every supported file in a directory when opts.recursive."""
        path = Path(path).expanduser()
        if not path.exists():
            raise NotFoundError(f"Path not found: {path}")
        if path.is_dir():
            pattern = "**/*" if opts.recursive else "*"
            files = sorted(p for p in path.glob(pattern) if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS)
            if not files:
                raise IngestError(f"No supported files in {path} ({', '.join(sorted(SUPPORTED_EXTS))})")
            return [self.import_file(f, opts) for f in files]
        return [self.import_file(path, opts)]

    def import_file(self, path: Path, opts: ImportOptions) -> ImportResult:
        """Import a single file with incremental skipping, validation and a single atomic write."""
        res = ImportResult(file=str(path))
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                raise IngestError("file exceeds size limit")
            raw = path.read_bytes()
        except OSError as exc:
            res.status = "failed"
            res.message = f"cannot read file: {exc}"
            return res
        sha = hashlib.sha256(raw).hexdigest()
        abs_path = str(path.resolve())
        if not opts.force and not opts.dry_run and self.db.find_import(abs_path, sha):
            res.status = "skipped_unchanged"
            res.message = "file content already imported (use --force to re-scan)"
            return res
        try:
            recs, errors, fmt, enc = parse_bytes(path.name, raw, opts)
        except IngestError as exc:
            res.status = "failed"
            res.message = str(exc)
            with self.db.transaction() as c:
                self.db.record_import(c, file_path=abs_path, file_sha256=sha, file_size=len(raw),
                                      fmt=opts.fmt, status="failed", notes=str(exc)[:500])
            return res
        res.fmt, res.encoding = fmt, enc
        res.total = len(recs) + len(errors)
        res.invalid = len(errors)
        res.errors = errors[:200]
        res.flagged = sum(1 for r in recs if r.flags and "possible_injection" in r.flags)
        res.undated = sum(1 for r in recs if "undated" in r.flags)
        res.conversations = len({r.conversation_id for r in recs})
        if opts.dry_run:
            existing = self.db.existing_dupkeys()
            res.duplicates = sum(1 for r in recs if r.dupkey and r.dupkey in existing)
            res.inserted = len(recs) - res.duplicates
            res.status = "dry_run"
            res.message = "dry run: nothing written"
            return res
        with self.db.transaction() as c:
            import_id = self.db.record_import(c, file_path=abs_path, file_sha256=sha, file_size=len(raw),
                                              fmt=fmt, encoding=enc, total=res.total, invalid=res.invalid,
                                              status="ok")
            ins, dups = self.db.insert_records(c, recs, import_id)
            c.execute("UPDATE imports SET inserted=?, duplicates=? WHERE import_id=?", (ins, dups, import_id))
        res.import_id, res.inserted, res.duplicates = import_id, ins, dups
        res.message = f"{ins} new, {dups} duplicates skipped, {res.invalid} invalid"
        if res.invalid:
            LOG.info("%s: %d invalid entries skipped", path.name, res.invalid)
        return res


# ==========================================================================
# 4. SEARCH ENGINE
# ==========================================================================
@dataclass
class SearchFilters:
    """Optional filters applied to every search mode."""
    date_from: Optional[str] = None
    date_to: Optional[str] = None
    conversation: Optional[str] = None
    topic: Optional[str] = None
    category: Optional[str] = None
    project: Optional[str] = None
    role: Optional[str] = None
    source: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    period: Optional[str] = None

    def clauses(self) -> Tuple[List[str], List[Any]]:
        """SQL WHERE fragments and parameters for these filters (on the `r` alias)."""
        w: List[str] = []
        p: List[Any] = []
        if self.period:
            lo, hi = period_bounds(self.period)
            w.append("r.ts BETWEEN ? AND ?")
            p += [lo, hi]
        if self.date_from:
            lo, _ = period_bounds(self.date_from)
            w.append("r.ts >= ?")
            p.append(lo)
        if self.date_to:
            _, hi = period_bounds(self.date_to)
            w.append("r.ts <= ?")
            p.append(hi)
        if self.conversation:
            w.append("r.conversation_id = ?")
            p.append(self.conversation)
        if self.topic:
            w.append("LOWER(r.topic) LIKE ?")
            p.append(f"%{self.topic.lower()}%")
        if self.category:
            w.append("LOWER(r.category) = ?")
            p.append(self.category.lower())
        if self.project:
            w.append("LOWER(r.project) = ?")
            p.append(self.project.lower())
        if self.role:
            w.append("r.role = ?")
            p.append(self.role.lower())
        if self.source:
            w.append("LOWER(r.source) LIKE ?")
            p.append(f"%{self.source.lower()}%")
        for t in self.tags:
            w.append("r.tags_text LIKE ?")
            p.append(f"%|{t.lower()}|%")
        return w, p


def parse_query(q: str) -> Tuple[List[str], List[str]]:
    """Split a query into (phrases, terms). Quoted text is a phrase."""
    phrases = [m.strip().lower() for m in re.findall(r'"([^"]+)"', q) if m.strip()]
    rest = re.sub(r'"[^"]*"', " ", q)
    terms = [t.lower() for t in _TOKEN_RE.findall(rest) if t.lower() not in STOPWORDS]
    return phrases, terms


def fts_quote(term: str) -> str:
    """Quote a term for FTS5 MATCH (escaping double quotes)."""
    return '"' + term.replace('"', '""') + '"'


def snippet_for(content: str, terms: Sequence[str], width: int = 220) -> str:
    """Short excerpt centred on the first matching term."""
    low = content.lower()
    pos = -1
    for t in terms:
        i = low.find(t.lower())
        if i >= 0 and (pos < 0 or i < pos):
            pos = i
    if pos < 0:
        return truncate(content, width)
    start = max(0, pos - width // 3)
    seg = content[start:start + width].replace("\n", " ")
    return ("…" if start > 0 else "") + seg + ("…" if start + width < len(content) else "")


class SearchEngine:
    """Keyword, full-text (FTS5 BM25), contextual (synonym + stem) and optional semantic search."""

    MAX_POOL = 5000
    _model_cache: Dict[str, Any] = {}

    def __init__(self, db: MemoryDB):
        self.db = db

    def search(self, query: str, mode: str = "auto", limit: int = 20,
               filters: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Run a search and return results with the method actually used and notes."""
        query = (query or "").strip()
        if not query:
            raise ValidationError("Search query is empty")
        if limit < 1 or limit > 1000:
            raise ValidationError("limit must be between 1 and 1000")
        filters = filters or SearchFilters()
        notes: List[str] = []
        mode = mode.lower()
        if mode not in {"auto", "keyword", "fulltext", "contextual", "semantic"}:
            raise ValidationError(f"Unknown search mode {mode!r}")
        if mode == "auto":
            mode = "fulltext" if self.db.has_fts() else "keyword"
        if mode == "semantic":
            results, used, note = self._semantic(query, limit, filters)
            if note:
                notes.append(note)
            if results is None:
                mode = "contextual"
                notes.append("Semantic search unavailable; falling back to contextual search.")
            else:
                return {"query": query, "method": used, "count": len(results), "results": results, "notes": notes}
        if mode == "keyword":
            results = self._keyword(query, limit, filters)
        elif mode == "fulltext":
            try:
                results = self._fulltext(query, limit, filters)
            except sqlite3.OperationalError as exc:
                notes.append(f"FTS5 unavailable for this query ({exc}); used keyword search.")
                results = self._keyword(query, limit, filters)
                mode = "keyword"
        else:
            results = self._contextual(query, limit, filters)
        return {"query": query, "method": mode, "count": len(results), "results": results, "notes": notes}

    def _rows(self, sql: str, params: List[Any]) -> List[sqlite3.Row]:
        return self.db.conn.execute(sql, params).fetchall()

    def _keyword(self, query: str, limit: int, f: SearchFilters) -> List[Dict[str, Any]]:
        phrases, terms = parse_query(query)
        needles = phrases + terms
        if not needles:
            raise ValidationError("Query contains only stopwords; be more specific")
        w, p = f.clauses()
        for n in needles:
            w.append("instr(r.content_lc, ?) > 0")
            p.append(n)
        sql = ("SELECT r.* FROM records r WHERE " + " AND ".join(w) +
               " ORDER BY r.ts DESC, r.seq DESC LIMIT ?")
        rows = self._rows(sql, p + [limit])
        out = []
        for r in rows:
            d = row_to_dict(r)
            d["score"] = float(sum(d["content"].lower().count(n) for n in needles))
            d["snippet"] = snippet_for(d["content"], needles)
            out.append(self._public(d))
        return out

    def _fulltext(self, query: str, limit: int, f: SearchFilters) -> List[Dict[str, Any]]:
        if not self.db.has_fts():
            return self._keyword(query, limit, f)
        phrases, terms = parse_query(query)
        toks = [fts_quote(x) for x in phrases + terms]
        if not toks:
            raise ValidationError("Query contains only stopwords; be more specific")
        match = " AND ".join(toks)
        w, p = f.clauses()
        where = (" AND " + " AND ".join(w)) if w else ""
        sql = (f"SELECT r.*, bm25(records_fts) AS rank FROM records_fts "
               f"JOIN records r ON r.id = records_fts.record_id "
               f"WHERE records_fts MATCH ?{where} ORDER BY rank LIMIT ?")
        rows = self._rows(sql, [match] + p + [limit])
        out = []
        for r in rows:
            d = row_to_dict(r)
            d["score"] = round(-float(d.pop("rank")), 4)
            d["snippet"] = snippet_for(d["content"], phrases + terms)
            out.append(self._public(d))
        return out

    def _pool(self, match_terms: List[str], f: SearchFilters) -> List[sqlite3.Row]:
        """Candidate records containing any of the terms (FTS OR), or all records within filters."""
        w, p = f.clauses()
        if self.db.has_fts() and match_terms:
            q = " OR ".join(fts_quote(t) for t in match_terms)
            where = (" AND " + " AND ".join(w)) if w else ""
            sql = (f"SELECT r.* FROM records_fts JOIN records r ON r.id = records_fts.record_id "
                   f"WHERE records_fts MATCH ?{where} LIMIT ?")
            return self._rows(sql, [q] + p + [self.MAX_POOL])
        sql = "SELECT r.* FROM records r" + (" WHERE " + " AND ".join(w) if w else "") + " ORDER BY r.ts DESC LIMIT ?"
        return self._rows(sql, p + [self.MAX_POOL])

    def _contextual(self, query: str, limit: int, f: SearchFilters) -> List[Dict[str, Any]]:
        """Score by stemmed-term overlap with synonym expansion and phrase bonus."""
        phrases, terms = parse_query(query)
        base = content_tokens(" ".join(terms + phrases), do_stem=True)
        if not base:
            raise ValidationError("Query contains only stopwords; be more specific")
        groups: List[Set[str]] = []
        for t in content_tokens(" ".join(terms + phrases), do_stem=False):
            g = {stem(t)} | {stem(x) for x in _SYN_MAP.get(t, set())}
            groups.append(g)
        expand_raw = {x for t in content_tokens(" ".join(terms), do_stem=False) for x in _SYN_MAP.get(t, set())}
        pool_terms = sorted({x for g in groups for x in g} | {stem(x) for x in expand_raw} | set(terms))
        rows = self._pool(pool_terms, f)
        scored: List[Tuple[float, sqlite3.Row]] = []
        for r in rows:
            toks = {stem(t) for t in content_tokens(r["content"], do_stem=False)}
            if not toks:
                continue
            matched = sum(1 for g in groups if g & toks)
            if matched == 0:
                continue
            coverage = matched / max(1, len(groups))
            phrase_bonus = 0.5 * sum(1 for ph in phrases if ph in r["content_lc"])
            density = matched / math.sqrt(len(toks))
            scored.append((coverage * 2 + density + phrase_bonus, r))
        scored.sort(key=lambda x: (-x[0], x[1]["ts"] or ""))
        out = []
        for s, r in scored[:limit]:
            d = row_to_dict(r)
            d["score"] = round(s, 4)
            d["snippet"] = snippet_for(d["content"], terms + phrases)
            out.append(self._public(d))
        return out

    def _semantic(self, query: str, limit: int, f: SearchFilters) -> Tuple[Optional[List[Dict[str, Any]]], str, Optional[str]]:
        """Local embedding search. Requires sentence-transformers AND a model already on disk."""
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore
        except ImportError:
            return None, "semantic", ("sentence-transformers is not installed "
                                      "(pip install sentence-transformers) — no network download attempted.")
        model_name = os.environ.get(ENV_MODEL, DEFAULT_MODEL)
        try:
            os.environ.setdefault("HF_HUB_OFFLINE", "1")
            os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
            if model_name not in self._model_cache:
                self._model_cache[model_name] = SentenceTransformer(model_name, local_files_only=True)
            model = self._model_cache[model_name]
        except Exception as exc:  # noqa: BLE001 - any load failure means fallback
            return None, "semantic", f"Embedding model '{model_name}' is not available locally ({type(exc).__name__})."
        w, p = f.clauses()
        sql = "SELECT r.* FROM records r" + (" WHERE " + " AND ".join(w) if w else "") + " ORDER BY r.ts DESC LIMIT ?"
        rows = self._rows(sql, p + [20000])
        if not rows:
            return [], "semantic", None
        texts = [r["content"][:1000] for r in rows]
        qv = model.encode([query], normalize_embeddings=True)[0]
        dv = model.encode(texts, normalize_embeddings=True, batch_size=64)
        scored = []
        for r, v in zip(rows, dv):
            s = float(sum(a * b for a, b in zip(qv, v)))
            scored.append((s, r))
        scored.sort(key=lambda x: -x[0])
        out = []
        for s, r in scored[:limit]:
            d = row_to_dict(r)
            d["score"] = round(s, 4)
            d["snippet"] = truncate(d["content"], 220)
            out.append(self._public(d))
        return out, "semantic", None

    @staticmethod
    def _public(d: Dict[str, Any]) -> Dict[str, Any]:
        """Result shape with source attribution always present."""
        return {
            "record_id": d["id"], "score": d.get("score"), "ts": d.get("ts"), "role": d.get("role"),
            "conversation_id": d.get("conversation_id"), "message_id": d.get("message_id"),
            "source": d.get("source"), "topic": d.get("topic"), "project": d.get("project"),
            "category": d.get("category"), "tags": d.get("tags") or [], "snippet": d.get("snippet"),
            "content": d.get("content"), "flags": d.get("flags") or [],
        }

    def cross_conversation(self, query: str, limit: int = 30, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Search, then group hits by conversation so evidence from several chats is combined."""
        res = self.search(query, mode="auto", limit=limit, filters=f)
        groups: Dict[str, Dict[str, Any]] = {}
        for r in res["results"]:
            g = groups.setdefault(r["conversation_id"], {"conversation_id": r["conversation_id"],
                                                         "topic": r["topic"], "hits": 0, "first": r["ts"],
                                                         "last": r["ts"], "sources": set()})
            g["hits"] += 1
            g["sources"].add(r["source"])
            if r["ts"] and (g["first"] is None or r["ts"] < g["first"]):
                g["first"] = r["ts"]
            if r["ts"] and (g["last"] is None or r["ts"] > g["last"]):
                g["last"] = r["ts"]
        for g in groups.values():
            g["sources"] = sorted(s for s in g["sources"] if s)
        res["conversations"] = sorted(groups.values(), key=lambda g: -g["hits"])
        return res


# ==========================================================================
# 5. ANALYTICS
# ==========================================================================
class Analytics:
    """Statistics over stored records. Never invents numbers: empty data gives empty results and notes."""

    def __init__(self, db: MemoryDB):
        self.db = db

    def _where(self, f: SearchFilters) -> Tuple[str, List[Any]]:
        w, p = f.clauses()
        return (" WHERE " + " AND ".join(w)) if w else "", p

    def overview(self, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Totals, role split, date span, average lengths and data-quality counts."""
        f = f or SearchFilters()
        where, p = self._where(f)
        c = self.db.conn
        row = c.execute(f"SELECT COUNT(*) n, COUNT(DISTINCT r.conversation_id) convs,"
                        f" SUM(r.role='user') users, SUM(r.role='assistant') assistants,"
                        f" AVG(LENGTH(r.content)) avg_len, MIN(r.ts) first, MAX(r.ts) last,"
                        f" SUM(r.ts IS NULL) undated, SUM(r.flags LIKE '%possible_injection%') flagged"
                        f" FROM records r{where}", p).fetchone()
        n = row["n"] or 0
        out = {
            "total_messages": n,
            "total_conversations": row["convs"] or 0,
            "user_messages": row["users"] or 0,
            "assistant_messages": row["assistants"] or 0,
            "other_role_messages": n - (row["users"] or 0) - (row["assistants"] or 0),
            "average_message_length_chars": round(row["avg_len"], 2) if row["avg_len"] else 0.0,
            "first_message": row["first"],
            "last_message": row["last"],
            "undated_messages": row["undated"] or 0,
            "flagged_messages": row["flagged"] or 0,
        }
        if n:
            out["average_messages_per_conversation"] = round(n / max(1, out["total_conversations"]), 2)
        else:
            out["note"] = "No records match; statistics are not available."
        return out

    def activity(self, grain: str = "month", f: Optional[SearchFilters] = None) -> List[Dict[str, Any]]:
        """Message counts per day, week, month or year."""
        f = f or SearchFilters()
        where, p = self._where(f)
        extra = " AND " if where else " WHERE "
        fmt = {"day": "substr(r.ts,1,10)", "month": "substr(r.ts,1,7)", "year": "substr(r.ts,1,4)"}
        if grain not in fmt and grain != "week":
            raise ValidationError("grain must be day, week, month or year")
        if grain == "week":
            rows = self.db.conn.execute(f"SELECT substr(r.ts,1,10) d, COUNT(*) n FROM records r{where}"
                                        f"{extra}r.ts IS NOT NULL GROUP BY d", p).fetchall()
            buckets: Dict[str, int] = collections.Counter()
            convs: Dict[str, Set[str]] = collections.defaultdict(set)
            for r in rows:
                buckets[iso_week(r["d"])] += r["n"]
            return [{"period": k, "messages": v} for k, v in sorted(buckets.items())]
        rows = self.db.conn.execute(
            f"SELECT {fmt[grain]} b, COUNT(*) n, COUNT(DISTINCT r.conversation_id) c FROM records r{where}"
            f"{extra}r.ts IS NOT NULL GROUP BY b ORDER BY b", p).fetchall()
        return [{"period": r["b"], "messages": r["n"], "conversations": r["c"]} for r in rows]

    def top_keywords(self, n: int = 20, f: Optional[SearchFilters] = None) -> List[Dict[str, Any]]:
        """Most frequent content words (stopwords removed)."""
        f = f or SearchFilters()
        where, p = self._where(f)
        counts: collections.Counter = collections.Counter()
        for r in self.db.conn.execute(f"SELECT r.content FROM records r{where}", p):
            counts.update(content_tokens(r["content"], min_len=3))
        total = sum(counts.values()) or 1
        return [{"keyword": k, "count": v, "share_pct": round(100 * v / total, 2)}
                for k, v in counts.most_common(n)]

    def distribution(self, column: str, f: Optional[SearchFilters] = None, n: int = 20) -> List[Dict[str, Any]]:
        """Counts for topic, category, project, source, role or conversation."""
        cols = {"topic": "r.topic", "category": "r.category", "project": "r.project",
                "source": "r.source", "role": "r.role", "conversation": "r.conversation_id"}
        if column not in cols:
            raise ValidationError(f"column must be one of {', '.join(cols)}")
        f = f or SearchFilters()
        where, p = self._where(f)
        rows = self.db.conn.execute(
            f"SELECT COALESCE(NULLIF({cols[column]}, ''), '(none)') k, COUNT(*) n FROM records r{where}"
            f" GROUP BY k ORDER BY n DESC LIMIT ?", p + [n]).fetchall()
        total = sum(r["n"] for r in rows) or 1
        return [{"value": r["k"], "count": r["n"], "share_pct": round(100 * r["n"] / total, 2)} for r in rows]

    def recurring_questions(self, min_count: int = 2, n: int = 20, f: Optional[SearchFilters] = None) -> List[Dict[str, Any]]:
        """User questions (containing '?') that are repeated, after normalisation."""
        f = f or SearchFilters()
        where, p = self._where(f)
        extra = " AND " if where else " WHERE "
        rows = self.db.conn.execute(f"SELECT r.content, r.ts FROM records r{where}{extra}r.role='user'"
                                    f" AND r.content LIKE '%?%'", p).fetchall()
        groups: Dict[str, List[str]] = collections.defaultdict(list)
        examples: Dict[str, str] = {}
        for r in rows:
            for q in re.split(r"(?<=\?)\s+", r["content"]):
                if "?" not in q:
                    continue
                key = " ".join(content_tokens(q, do_stem=True))
                if len(key) < 8:
                    continue
                groups[key].append(r["ts"] or "")
                examples.setdefault(key, q.strip()[:200])
        out = [{"question": examples[k], "occurrences": len(v), "first": min(x for x in v if x) if any(v) else None,
                "last": max(v) if any(v) else None}
               for k, v in groups.items() if len(v) >= min_count]
        out.sort(key=lambda x: -x["occurrences"])
        return out[:n]

    def compare_periods(self, period_a: str, period_b: str, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Compare message/conversation counts, average length and top topics between two periods."""
        a_lo, a_hi = period_bounds(period_a)
        b_lo, b_hi = period_bounds(period_b)
        base = f or SearchFilters()
        fa = SearchFilters(**{**base.__dict__, "period": None, "date_from": a_lo, "date_to": a_hi})
        fb = SearchFilters(**{**base.__dict__, "period": None, "date_from": b_lo, "date_to": b_hi})
        oa, ob = self.overview(fa), self.overview(fb)
        metrics = {}
        for key in ("total_messages", "total_conversations", "user_messages", "assistant_messages",
                    "average_message_length_chars"):
            va, vb = oa.get(key, 0) or 0, ob.get(key, 0) or 0
            metrics[key] = {"period_a": va, "period_b": vb, "absolute_change": round(vb - va, 2),
                            "percent_change": pct_change(va, vb)}
        return {"period_a": {"label": period_a, "from": a_lo, "to": a_hi},
                "period_b": {"label": period_b, "from": b_lo, "to": b_hi},
                "metrics": metrics,
                "formula": "percent_change = (period_b - period_a) / period_a * 100",
                "top_topics_a": self.distribution("topic", fa, 5),
                "top_topics_b": self.distribution("topic", fb, 5),
                "note": "percent_change is undefined when period_a is zero and is shown as null."}

    def full(self, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Complete statistics bundle."""
        f = f or SearchFilters()
        return {
            "overview": self.overview(f),
            "activity_by_month": self.activity("month", f),
            "activity_by_year": self.activity("year", f),
            "top_topics": self.distribution("topic", f, 10),
            "top_projects": self.distribution("project", f, 10),
            "top_categories": self.distribution("category", f, 10),
            "top_keywords": self.top_keywords(15, f),
            "recurring_questions": self.recurring_questions(2, 10, f),
        }


def pct_change(a: float, b: float) -> Optional[float]:
    """Percentage change from a to b; None when a is zero."""
    if a == 0:
        return None
    return round((b - a) / abs(a) * 100, 2)


# ==========================================================================
# 6. NUMERICAL ENGINE
# ==========================================================================
getcontext().prec = 28
_ALLOWED_FUNCS = {"sqrt": math.sqrt, "abs": abs, "round": round, "min": min, "max": max,
                  "log": math.log, "log10": math.log10, "exp": math.exp, "floor": math.floor, "ceil": math.ceil}
_ALLOWED_CONST = {"pi": math.pi, "e": math.e}


class SafeCalculator:
    """Evaluates arithmetic expressions by walking a whitelisted AST (no eval/exec)."""

    MAX_EXPR = 500

    def evaluate(self, expr: str) -> Dict[str, Any]:
        """Return result plus the parsed expression, for showing the formula."""
        if not expr or len(expr) > self.MAX_EXPR:
            raise ValidationError("Expression is empty or too long")
        expr = expr.replace("^", "**").replace("×", "*").replace("÷", "/").replace(",", ".") \
            if re.fullmatch(r"[\d\s.,+\-*/()%^×÷]+", expr) and "," in expr and "(" not in expr else expr.replace("^", "**")
        try:
            tree = ast.parse(expr, mode="eval")
        except SyntaxError as exc:
            raise ValidationError(f"Invalid expression: {exc.msg}") from exc
        value = self._eval(tree.body, 0)
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            raise ValidationError("Result is not a finite number")
        return {"expression": expr, "result": value if not isinstance(value, Decimal) else float(value)}

    def _eval(self, node: ast.AST, depth: int) -> Any:
        if depth > 60:
            raise ValidationError("Expression too deeply nested")
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return node.value
        if isinstance(node, ast.Name) and node.id in _ALLOWED_CONST:
            return _ALLOWED_CONST[node.id]
        if isinstance(node, ast.BinOp):
            a, b = self._eval(node.left, depth + 1), self._eval(node.right, depth + 1)
            if isinstance(node.op, ast.Add):
                return a + b
            if isinstance(node.op, ast.Sub):
                return a - b
            if isinstance(node.op, ast.Mult):
                return a * b
            if isinstance(node.op, ast.Div):
                if b == 0:
                    raise ValidationError("Division by zero")
                return a / b
            if isinstance(node.op, ast.Mod):
                if b == 0:
                    raise ValidationError("Modulo by zero")
                return a % b
            if isinstance(node.op, ast.Pow):
                if abs(b) > 1000:
                    raise ValidationError("Exponent too large")
                return a ** b
            raise ValidationError("Operator not allowed")
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            v = self._eval(node.operand, depth + 1)
            return -v if isinstance(node.op, ast.USub) else v
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _ALLOWED_FUNCS \
                and not node.keywords:
            args = [self._eval(a, depth + 1) for a in node.args]
            if len(args) > 5:
                raise ValidationError("Too many arguments")
            return _ALLOWED_FUNCS[node.func.id](*args)
        raise ValidationError("Only numbers, + - * / % **, parentheses and sqrt/log/min/max/abs/round are allowed")


_NUM_RE = re.compile(
    r"(?P<cur>[$€£]|USD|EUR|GBP|KES|Ksh|FCFA|XOF|CFA)?\s?(?P<num>-?\d{1,3}(?:[ ,. ]\d{3})*(?:[.,]\d+)?|-?\d+(?:[.,]\d+)?)"
    r"\s?(?P<unit>%|percent|km|m|kg|g|h|hours?|hrs?|days?|min|minutes?|€|\$|USD|EUR|KES|GBP|users?|items?|x)?",
    re.I)
_UNIT_DIM = {"%": "percent", "percent": "percent", "km": "length", "m": "length", "kg": "mass", "g": "mass",
             "h": "time", "hour": "time", "hours": "time", "hrs": "time", "hr": "time", "day": "time",
             "days": "time", "min": "time", "minute": "time", "minutes": "time",
             "$": "currency:USD", "usd": "currency:USD", "€": "currency:EUR", "eur": "currency:EUR",
             "gbp": "currency:GBP", "£": "currency:GBP", "ksh": "currency:KES", "kes": "currency:KES",
             "fcfa": "currency:XOF", "xof": "currency:XOF", "cfa": "currency:XOF"}
_CUR_TO_UNIT = {"$": "USD", "€": "EUR", "£": "GBP", "KES": "KES", "Ksh": "KES", "USD": "USD", "EUR": "EUR",
                "GBP": "GBP", "FCFA": "XOF", "XOF": "XOF", "CFA": "XOF"}


def parse_number(s: str) -> Optional[float]:
    """Parse '1 200,50', '1,200.50', '1.200,50' or '1200' into a float; None if ambiguous/invalid."""
    s = s.replace(" ", " ").replace(" ", "").strip()
    if not s or not re.fullmatch(r"-?[\d.,]+", s):
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        head, _, tail = s.rpartition(",")
        s = s.replace(",", "") if len(tail) == 3 and "," in head or len(tail) == 3 else s.replace(",", ".")
    elif s.count(".") > 1:
        s = s.replace(".", "")
    elif "." in s and len(s.split(".")[1]) == 3 and s.split(".")[0] not in ("0",):
        pass  # treat as decimal (e.g. 1.250) to avoid guessing thousands separators
    try:
        return float(s)
    except ValueError:
        return None


_DATE_BLANK_RE = re.compile(r"\b\d{4}-\d{1,2}-\d{1,2}(?:[T ]\d{1,2}:\d{2}(?::\d{2})?)?\b|\b\d{1,2}:\d{2}(?::\d{2})?\b")


def extract_quantities(text: str) -> List[Dict[str, Any]]:
    """Find numbers with optional currency/unit. Dates and years are skipped. Units are kept, never mixed."""
    out: List[Dict[str, Any]] = []
    # Blank out ISO dates and clock times so their digits are never read as quantities (same length kept).
    text = _DATE_BLANK_RE.sub(lambda m: " " * len(m.group(0)), text)
    for m in _NUM_RE.finditer(text):
        raw_num = m.group("num")
        if re.fullmatch(r"(19|20)\d{2}", raw_num) and not m.group("cur") and not m.group("unit"):
            continue
        if re.search(r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", text[max(0, m.start() - 1):m.end() + 6]):
            continue
        v = parse_number(raw_num)
        if v is None:
            continue
        cur, unit = m.group("cur"), (m.group("unit") or "")
        dim = None
        if cur:
            dim = "currency:" + _CUR_TO_UNIT.get(cur, cur)
        elif unit:
            dim = _UNIT_DIM.get(unit.lower(), _UNIT_DIM.get(unit, unit.lower()))
        ctx = text[max(0, m.start() - 40):m.end() + 20].replace("\n", " ")
        out.append({"value": v, "unit": dim or "unitless", "raw": m.group(0).strip(), "context": ctx.strip()})
    return out


class NumericEngine:
    """Aggregates numbers extracted from records; groups by unit so incompatible units are never combined."""

    def __init__(self, db: MemoryDB):
        self.db = db
        self.calc = SafeCalculator()

    def extract_from_search(self, query: str, f: Optional[SearchFilters] = None, limit: int = 2000) -> List[Dict[str, Any]]:
        """Quantities extracted from records matching a query (or all records when query is '*')."""
        f = f or SearchFilters()
        w, p = f.clauses()
        if query and query != "*":
            phrases, terms = parse_query(query)
            for n in phrases + terms:
                w.append("instr(r.content_lc, ?) > 0")
                p.append(n)
        sql = "SELECT r.id, r.ts, r.content FROM records r" + (" WHERE " + " AND ".join(w) if w else "") + " ORDER BY r.ts LIMIT ?"
        items = []
        for r in self.db.conn.execute(sql, p + [limit]):
            for q in extract_quantities(r["content"]):
                q.update({"record_id": r["id"], "ts": r["ts"]})
                items.append(q)
        return items

    def summarize(self, items: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        """Per-unit summary: count, sum, mean, median, min, max, stdev, distribution quartiles."""
        groups: Dict[str, List[float]] = collections.defaultdict(list)
        for it in items:
            groups[it["unit"]].append(it["value"])
        summary = {}
        for unit, vals in groups.items():
            vals_sorted = sorted(vals)
            n = len(vals)
            entry: Dict[str, Any] = {"count": n, "sum": round(sum(vals), 6), "mean": round(statistics.fmean(vals), 6),
                                     "median": statistics.median(vals), "min": vals_sorted[0], "max": vals_sorted[-1],
                                     "formula": "mean = sum / count"}
            if n >= 2:
                entry["stdev_sample"] = round(statistics.stdev(vals), 6)
                q = statistics.quantiles(vals, n=4, method="inclusive")
                entry["quartiles"] = {"q1": q[0], "q2": q[1], "q3": q[2]}
            summary[unit] = entry
        return {"units": summary, "items": len(items),
                "assumptions": ["Units are kept separate; values are never summed across different units.",
                                "Numbers are extracted by pattern; a number may be mis-read from context. Check 'context' fields."]}

    def trend(self, items: Sequence[Dict[str, Any]], unit: str) -> Dict[str, Any]:
        """Per-month mean for one unit and first-to-last percentage change."""
        by_month: Dict[str, List[float]] = collections.defaultdict(list)
        for it in items:
            if it["unit"] == unit and it["ts"]:
                by_month[it["ts"][:7]].append(it["value"])
        months = sorted(by_month)
        means = {m: round(statistics.fmean(by_month[m]), 4) for m in months}
        change = pct_change(means[months[0]], means[months[-1]]) if len(months) >= 2 else None
        return {"unit": unit, "monthly_mean": means,
                "first_to_last_percent_change": change,
                "formula": "percent_change = (last_month_mean - first_month_mean) / first_month_mean * 100",
                "note": ("Requires at least two dated months." if len(months) < 2 else
                         "All records with this unit are pooled. Narrow with --project/--from/--to to compare like with like.")}


# ==========================================================================
# 7. REASONING HELPERS (evidence packs, chronology, changes)
# ==========================================================================
DECISION_RE = re.compile(r"\b(decid\w*|decision|chose|choose|we will|i will go with|go with|agreed|final(?:ly)?|"
                         r"d[ée]cid\w*|choisi|on part sur)\b", re.I)
PROBLEM_RE = re.compile(r"\b(bug|error|problem|issue|blocked|fail\w*|broken|crash\w*|erreur|probl[èe]me|bloqu\w*)\b", re.I)
TODO_RE = re.compile(r"\b(todo|to do|next step|pending|need to|must|should|à faire|reste à)\b", re.I)
DONE_RE = re.compile(r"\b(done|completed|finished|shipped|released|terminé|fini|livr\w*)\b", re.I)
GOAL_RE = re.compile(r"\b(goal|objective|aim|target|objectif|but)\b", re.I)
REQ_RE = re.compile(r"\b(requirement|must have|needs? to|shall|exigence|requis)\b", re.I)
PROJECT_RE = re.compile(r"\b(?:project|projet)\s*[:\-]?\s*[\"“]?([A-Z][\w\-]{1,40}(?:\s[A-Z][\w\-]{1,40}){0,2})", re.U)
MONEY_RE = re.compile(r"\b(budget|cost|price|coût|prix)\b", re.I)
PREF_RE = re.compile(r"\bI\s+(?P<neg>don'?t\s+|do not\s+)?(?P<verb>like|prefer|want|use|love|hate|avoid)\s+(?P<obj>[\w\- ]{2,40})", re.I)


def split_sentences(text: str) -> List[str]:
    """Rough sentence split (keeps lines)."""
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if p and p.strip()]


class Reasoner:
    """Builds evidence-based answers: retrieves records, orders them, separates facts from interpretation."""

    def __init__(self, db: MemoryDB):
        self.db = db
        self.search = SearchEngine(db)

    def evidence(self, question: str, limit: int = 25, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Evidence pack for a question. Returns records in chronological order and an explicit sufficiency statement."""
        res = self.search.search(question, mode="auto", limit=limit, filters=f)
        hits = sorted(res["results"], key=lambda r: (r["ts"] or "", r["record_id"]))
        decisions = [h for h in hits if DECISION_RE.search(h["content"])]
        problems = [h for h in hits if PROBLEM_RE.search(h["content"])]
        dated = [h for h in hits if h["ts"]]
        if not hits:
            sufficiency = "The available records do not establish an answer: no matching records were found."
        elif len(hits) < 2:
            sufficiency = "Only one matching record was found; the evidence is thin and may not establish the answer."
        else:
            sufficiency = (f"{len(hits)} matching records found across {len({h['conversation_id'] for h in hits})} "
                           "conversation(s). Verify the cited records before relying on them.")
        return {
            "question": question,
            "search_method": res["method"],
            "notes": res["notes"],
            "sufficiency": sufficiency,
            "chronology": [self._cite(h) for h in hits],
            "decision_records": [self._cite(h) for h in decisions],
            "problem_records": [self._cite(h) for h in problems],
            "earliest": dated[0]["ts"] if dated else None,
            "latest": dated[-1]["ts"] if dated else None,
            "facts_vs_interpretation": "Quoted content is FACT (present in records). Any link between records is "
                                       "INTERPRETATION and must be labelled as such in the answer.",
            "not_available": "Content outside the imported records is NOT available to this engine.",
        }

    @staticmethod
    def _cite(h: Dict[str, Any]) -> Dict[str, Any]:
        return {"record_id": h["record_id"], "ts": h["ts"], "role": h["role"], "conversation_id": h["conversation_id"],
                "source": h["source"], "snippet": h["snippet"]}

    def changes_over_time(self, term: str, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Chronological mentions of a term with a count per year; useful for evolution of an idea."""
        res = self.search.search(term, mode="keyword", limit=1000, filters=f)
        hits = sorted(res["results"], key=lambda r: r["ts"] or "")
        per_year: Dict[str, int] = collections.Counter((h["ts"] or "unknown")[:4] for h in hits)
        return {"term": term, "mentions": len(hits), "per_year": dict(sorted(per_year.items())),
                "first": hits[0]["ts"] if hits else None, "last": hits[-1]["ts"] if hits else None,
                "chronology": [self._cite(h) for h in hits[:200]],
                "note": "Mentions show when a term appears in records; they do not prove a belief or decision changed."}

    def preferences(self, f: Optional[SearchFilters] = None) -> List[Dict[str, Any]]:
        """Stated preferences ('I prefer X', 'I like X') in user messages, chronologically."""
        w, p = (f or SearchFilters()).clauses()
        w.append("r.role = 'user'")
        rows = self.db.conn.execute("SELECT r.id, r.ts, r.content FROM records r WHERE " + " AND ".join(w) +
                                    " ORDER BY r.ts", p).fetchall()
        out = []
        for r in rows:
            for m in PREF_RE.finditer(r["content"]):
                out.append({"record_id": r["id"], "ts": r["ts"],
                            "statement": ("NOT " if m.group("neg") else "") + f"{m.group('verb')} {m.group('obj').strip()}",
                            "snippet": truncate(r["content"], 200)})
        return out


# ==========================================================================
# 8. PROJECT INTELLIGENCE
# ==========================================================================
class ProjectEngine:
    """Discovers and tracks projects from the `project` field and 'project X' mentions in content."""

    def __init__(self, db: MemoryDB):
        self.db = db

    def names(self) -> List[Dict[str, Any]]:
        """Stored project summary rows."""
        rows = self.db.conn.execute("SELECT name, first_seen, latest, record_count FROM projects ORDER BY record_count DESC, name").fetchall()
        return [dict(r) for r in rows]

    def _records_for(self, name: str) -> List[Dict[str, Any]]:
        rows = self.db.conn.execute(
            "SELECT r.* FROM records r WHERE LOWER(r.project)=? OR instr(r.content_lc, ?) > 0 ORDER BY r.ts, r.seq",
            (name.lower(), name.lower())).fetchall()
        return [row_to_dict(r) for r in rows]

    def discover(self, min_mentions: int = 3, n: int = 30) -> List[Dict[str, Any]]:
        """Candidate project names mentioned as 'project X' in the content (never invented)."""
        counts: collections.Counter = collections.Counter()
        for r in self.db.conn.execute("SELECT content FROM records"):
            for m in PROJECT_RE.finditer(r["content"]):
                counts[m.group(1).strip()] += 1
        return [{"name": k, "mentions": v} for k, v in counts.most_common(n) if v >= min_mentions]

    def report(self, name: str, f: Optional[SearchFilters] = None) -> Dict[str, Any]:
        """Detailed project report with sourced items; status is 'completed' only with explicit completion evidence."""
        recs = self._records_for(name)
        if not recs:
            raise NotFoundError(f"No records mention project {name!r}. Try `projects` to list known names.")
        if f:
            recs = [r for r in recs if (not f.date_from or (r["ts"] or "") >= period_bounds(f.date_from)[0])
                    and (not f.date_to or (r["ts"] or "") <= period_bounds(f.date_to)[1])]
        goals, reqs, decisions, problems, done, pending, important = [], [], [], [], [], [], []
        for r in recs:
            cite = {"record_id": r["id"], "ts": r["ts"], "conversation_id": r["conversation_id"], "role": r["role"]}
            for s in split_sentences(r["content"]):
                snippet = truncate(s, 240)
                if GOAL_RE.search(s):
                    goals.append({**cite, "text": snippet})
                if REQ_RE.search(s):
                    reqs.append({**cite, "text": snippet})
                if DECISION_RE.search(s):
                    decisions.append({**cite, "text": snippet})
                if PROBLEM_RE.search(s):
                    problems.append({**cite, "text": snippet})
                if DONE_RE.search(s):
                    done.append({**cite, "text": snippet})
                elif TODO_RE.search(s):
                    pending.append({**cite, "text": snippet})
                if MONEY_RE.search(s) or re.search(r"\b(deadline|launch|release|due)\b", s, re.I):
                    important.append({**cite, "text": snippet})
        ts = [r["ts"] for r in recs if r["ts"]]
        completion_evidence = bool(done)
        status = "completion_mentioned" if completion_evidence else "active_or_unknown"
        convs = sorted({r["conversation_id"] for r in recs})
        recs_sorted_by_dates = ts
        last = max(recs_sorted_by_dates) if recs_sorted_by_dates else None
        objective = goals[0]["text"] if goals else ""
        next_actions = [p["text"] for p in pending[-5:]] if pending else []
        return {
            "project": name,
            "status": status,
            "status_note": ("Completion words appear in records; confirm manually before treating the project as complete."
                            if completion_evidence else
                            "No completion evidence in records. The project is NOT marked completed."),
            "record_count": len(recs),
            "conversations": convs,
            "first_mentioned": ts[0] if ts else None,
            "latest_activity": last,
            "initial_objective": objective or "Not established by records.",
            "goals": goals[:30], "requirements": reqs[:30], "decisions": decisions[:30],
            "problems": problems[:30], "completed_tasks": done[:30], "pending_tasks": pending[:30],
            "important_dates": important[:30],
            "dependencies": [],
            "dependencies_note": "Dependencies are not extracted automatically; no records establish them.",
            "next_recommended_actions": next_actions or ["No pending items found; review the latest records."],
            "chronology": [{"ts": r["ts"], "role": r["role"], "record_id": r["id"],
                            "snippet": truncate(r["content"], 160)} for r in recs[:200]],
            "sources_note": "Every item cites record_id and ts. Items are extracted by keyword rules and may be imprecise.",
        }

    def refresh(self) -> int:
        """Recompute project counts and dates from records."""
        with self.db.transaction() as c:
            rows = c.execute("SELECT project, MIN(ts) f, MAX(ts) l, COUNT(*) n FROM records"
                             " WHERE project <> '' GROUP BY project").fetchall()
            c.execute("DELETE FROM projects")
            now = utc_now_iso()
            for r in rows:
                c.execute("INSERT INTO projects(name, first_seen, latest, record_count, updated_at) VALUES (?,?,?,?,?)",
                          (r["project"], r["f"], r["l"], r["n"], now))
        return len(rows)


# ==========================================================================
# 9. CONTRADICTION & CHANGE DETECTION
# ==========================================================================
class ContradictionDetector:
    """Produces a review queue. Changes over time are classified as updates unless the evidence is inconsistent."""

    UPDATE_WORDS = re.compile(r"\b(now|updated?|instead|changed?|revised|new|switched|moved|actually|maintenant|mis à jour)\b", re.I)

    def __init__(self, db: MemoryDB):
        self.db = db

    def review_queue(self, limit: int = 200) -> List[Dict[str, Any]]:
        """Potentially conflicting records. Each item has records, dates, sources, nature, confidence, reason."""
        queue: List[Dict[str, Any]] = []
        queue += self._money_conflicts()
        queue += self._preference_conflicts()
        queue += self._date_conflicts()
        queue.sort(key=lambda x: (-x["confidence_score"], x["subject"]))
        return queue[:limit]

    def _money_conflicts(self) -> List[Dict[str, Any]]:
        by_project: Dict[str, List[Tuple[Dict[str, Any], Dict[str, Any]]]] = collections.defaultdict(list)
        rows = self.db.conn.execute("SELECT * FROM records WHERE project <> '' ORDER BY ts").fetchall()
        for r in rows:
            d = row_to_dict(r)
            if not MONEY_RE.search(d["content"]):
                continue
            for q in extract_quantities(d["content"]):
                if str(q["unit"]).startswith("currency:"):
                    by_project[d["project"]].append((d, q))
        out = []
        for proj, items in by_project.items():
            vals = {}
            for d, q in items:
                vals.setdefault((q["unit"], round(q["value"], 2)), []).append(d)
            if len(vals) < 2:
                continue
            keys = sorted(vals, key=lambda k: min(x["ts"] or "" for x in vals[k]))
            first, last = vals[keys[0]][0], vals[keys[-1]][0]
            updated = bool(self.UPDATE_WORDS.search(last["content"]))
            out.append({
                "subject": f"Budget/cost figure for project '{proj}'",
                "nature": "updated_information" if updated else "possible_inconsistency",
                "records": [{"record_id": x["id"], "ts": x["ts"], "source": x["source"], "value": f"{k[1]} {k[0]}"}
                            for k in keys for x in vals[k][:2]],
                "confidence_score": 0.6 if updated else 0.8,
                "confidence": "medium" if updated else "high",
                "why_review": ("A later record uses update wording; confirm it replaces the earlier figure."
                               if updated else "Different amounts appear without update wording; a human must decide which is correct."),
            })
        return out

    def _preference_conflicts(self) -> List[Dict[str, Any]]:
        rows = self.db.conn.execute("SELECT r.id, r.ts, r.source, r.content FROM records r WHERE r.role='user' ORDER BY r.ts").fetchall()
        pos: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
        neg: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
        for r in rows:
            for m in PREF_RE.finditer(r["content"]):
                words = [w for w in m.group("obj").lower().split() if w not in STOPWORDS]
                obj = " ".join(words[:2])
                if len(obj) < 3:
                    continue
                (neg if m.group("neg") else pos)[obj].append(dict(r))
        out = []
        for obj in set(pos) & set(neg):
            a, b = pos[obj][0], neg[obj][-1]
            changed = a["ts"] != b["ts"]
            out.append({
                "subject": f"Stated preference regarding '{obj}'",
                "nature": "changed_preference" if changed else "genuine_inconsistency",
                "records": [{"record_id": a["id"], "ts": a["ts"], "source": a["source"], "value": "positive"},
                            {"record_id": b["id"], "ts": b["ts"], "source": b["source"], "value": "negative"}],
                "confidence_score": 0.5 if changed else 0.85,
                "confidence": "low" if changed else "high",
                "why_review": ("Preference may have changed over time; a change is not automatically a contradiction."
                               if changed else "Positive and negative statements on the same day conflict."),
            })
        return out

    def _date_conflicts(self) -> List[Dict[str, Any]]:
        pat = re.compile(r"\b(deadline|launch|release|due|meeting|delivery)\b[^.\n]{0,40}?(\d{4}-\d{2}-\d{2}|\d{1,2} (?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{4})", re.I)
        by_event: Dict[str, List[Tuple[str, Dict[str, Any]]]] = collections.defaultdict(list)
        for r in self.db.conn.execute("SELECT * FROM records ORDER BY ts"):
            d = row_to_dict(r)
            for m in pat.finditer(d["content"]):
                ev = m.group(1).lower()
                dv = m.group(2)
                try:
                    norm = dt.datetime.strptime(dv[:10], "%Y-%m-%d").date().isoformat() if "-" in dv else \
                        parse_timestamp(dv).date().isoformat()  # type: ignore[union-attr]
                except (ValueError, AttributeError):
                    continue
                by_event[ev].append((norm, d))
        out = []
        for ev, items in by_event.items():
            dates = {x[0] for x in items}
            if len(dates) < 2:
                continue
            first, last = items[0][1], items[-1][1]
            out.append({
                "subject": f"Date of '{ev}'",
                "nature": "possible_date_conflict",
                "records": [{"record_id": d["id"], "ts": d["ts"], "source": d["source"], "value": v} for v, d in items[:6]],
                "confidence_score": 0.7,
                "confidence": "medium",
                "why_review": "Different dates are given for the same event; the later one may be a reschedule.",
            })
        return out


# ==========================================================================
# 10. TIMELINE
# ==========================================================================
class Timeline:
    """Chronological reconstruction with filters and milestone detection."""

    def __init__(self, db: MemoryDB):
        self.db = db

    def build(self, f: Optional[SearchFilters] = None, keyword: Optional[str] = None,
              milestones_only: bool = False, limit: int = 2000) -> List[Dict[str, Any]]:
        """Dated records in order. milestones_only keeps decisions, problems and completion statements."""
        f = f or SearchFilters()
        w, p = f.clauses()
        w.append("r.ts IS NOT NULL")
        if keyword:
            phrases, terms = parse_query(keyword)
            for n in phrases + terms:
                w.append("instr(r.content_lc, ?) > 0")
                p.append(n)
        rows = self.db.conn.execute("SELECT r.* FROM records r WHERE " + " AND ".join(w) +
                                    " ORDER BY r.ts, r.seq LIMIT ?", p + [limit]).fetchall()
        out = []
        for r in rows:
            d = row_to_dict(r)
            kinds = []
            if DECISION_RE.search(d["content"]):
                kinds.append("decision")
            if PROBLEM_RE.search(d["content"]):
                kinds.append("problem")
            if DONE_RE.search(d["content"]):
                kinds.append("completion_mention")
            if milestones_only and not kinds:
                continue
            out.append({"ts": d["ts"], "record_id": d["id"], "role": d["role"], "conversation_id": d["conversation_id"],
                        "project": d["project"], "source": d["source"], "kinds": kinds,
                        "snippet": truncate(d["content"], 200)})
        return out


# ==========================================================================
# 11. REPORTS & EXPORTS
# ==========================================================================
EXPORT_FORMATS = ("json", "jsonl", "csv", "txt", "md", "html", "pdf", "docx")
RECORD_COLUMNS = ["id", "ts", "conversation_id", "message_id", "role", "source", "topic", "category", "project",
                  "tags", "related", "flags", "content"]


def _rows_for_export(items: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for it in items:
        d = dict(it)
        for k in ("tags", "related", "flags"):
            if isinstance(d.get(k), list):
                d[k] = "|".join(map(str, d[k]))
        out.append(d)
    return out


def render_markdown(title: str, sections: List[Tuple[str, Any]], sources: List[str]) -> str:
    """Markdown report. sections are (heading, payload) where payload is str, list of dicts or dict."""
    lines = [f"# {title}", "", f"_Generated {utc_now_iso()} by Memory Intelligence {__version__}_", ""]
    for head, body in sections:
        lines += [f"## {head}", ""]
        if isinstance(body, str):
            lines += [body, ""]
        elif isinstance(body, dict):
            for k, v in body.items():
                lines.append(f"- **{k}**: {v}")
            lines.append("")
        elif not isinstance(body, (list, tuple)):
            lines += [str(body), ""]
        else:
            for item in body:
                if isinstance(item, dict):
                    lines.append("- " + "; ".join(f"{k}: {truncate(str(v), 220)}" for k, v in item.items()
                                                  if not isinstance(v, (list, dict))))
                else:
                    lines.append(f"- {item}")
            lines.append("")
    lines += ["## Data sources and limitations", ""]
    lines += [f"- {s}" for s in sources]
    lines += ["- Only imported records are analysed. Private or account-wide history is not accessible.", ""]
    return "\n".join(lines)


def render_text(md: str) -> str:
    """Strip Markdown markers for a plain-text export."""
    out = []
    for ln in md.split("\n"):
        ln = re.sub(r"^#+\s*", "", ln).replace("**", "").replace("_", "") if not ln.startswith("|") else ln
        out.append(ln[2:] if ln.startswith("- ") else ln)
    return "\n".join(out)


def render_html(title: str, md: str) -> str:
    """Self-contained HTML (escaped, no scripts)."""
    body = []
    for ln in md.split("\n"):
        if ln.startswith("# "):
            body.append(f"<h1>{html.escape(ln[2:])}</h1>")
        elif ln.startswith("## "):
            body.append(f"<h2>{html.escape(ln[3:])}</h2>")
        elif ln.startswith("- "):
            body.append(f"<li>{html.escape(ln[2:])}</li>")
        elif ln.strip():
            body.append(f"<p>{html.escape(ln)}</p>")
    return ("<!doctype html><html lang='en'><head><meta charset='utf-8'>"
            f"<title>{html.escape(title)}</title>"
            "<style>body{font-family:system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem;line-height:1.5}"
            "li{margin:.2rem 0}</style></head><body>" + "".join(body) + "</body></html>")


class Exporter:
    """Writes reports and archives to explicit output paths. Refuses to overwrite unless force=True."""

    def __init__(self, db: MemoryDB):
        self.db = db

    def _write(self, out: Path, data: str | bytes, force: bool) -> Path:
        out = Path(out).expanduser()
        if out.exists() and not force:
            raise ConfirmationRequired(f"{out} exists; use --force to overwrite")
        out.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(data, bytes):
            out.write_bytes(data)
        else:
            out.write_text(data, encoding="utf-8", newline="\n")
        return out

    def export_records(self, items: Sequence[Dict[str, Any]], fmt: str, out: Path, force: bool = False,
                       title: str = "Memory export") -> Dict[str, Any]:
        """Export records (already-decoded dicts) to a format."""
        fmt = fmt.lower()
        if fmt not in EXPORT_FORMATS:
            raise ValidationError(f"Format must be one of {', '.join(EXPORT_FORMATS)}")
        if fmt == "json":
            path = self._write(out, jdumps(list(items)), force)
        elif fmt == "jsonl":
            path = self._write(out, "\n".join(json.dumps(i, ensure_ascii=False, default=str) for i in items) + "\n", force)
        elif fmt == "csv":
            buf = io.StringIO()
            w = csv.DictWriter(buf, fieldnames=RECORD_COLUMNS, extrasaction="ignore")
            w.writeheader()
            for row in _rows_for_export(items):
                w.writerow({k: row.get(k, "") for k in RECORD_COLUMNS})
            path = self._write(out, buf.getvalue(), force)
        else:
            md = render_markdown(title, [("Records", [
                {"ts": i.get("ts"), "role": i.get("role"), "conversation": i.get("conversation_id"),
                 "source": i.get("source"), "id": i.get("id") or i.get("record_id"),
                 "text": i.get("content") or i.get("snippet")} for i in items])],
                ["Exported from the local Memory Intelligence database."])
            if fmt == "md":
                path = self._write(out, md, force)
            elif fmt == "txt":
                path = self._write(out, render_text(md), force)
            elif fmt == "html":
                path = self._write(out, render_html(title, md), force)
            elif fmt == "pdf":
                path = self._write(out, render_pdf(title, md), force)
            else:
                path = self._write(out, render_docx(title, md), force)
        return {"path": str(path), "format": fmt, "items": len(items), "bytes": path.stat().st_size}

    def export_report(self, title: str, sections: List[Tuple[str, Any]], sources: List[str], fmt: str,
                      out: Path, force: bool = False) -> Dict[str, Any]:
        """Export a structured report (stats, project, intelligence) in any text/binary format."""
        md = render_markdown(title, sections, sources)
        fmt = fmt.lower()
        if fmt == "md":
            data: str | bytes = md
        elif fmt == "txt":
            data = render_text(md)
        elif fmt == "html":
            data = render_html(title, md)
        elif fmt == "json":
            data = jdumps({"title": title, "sections": [{"heading": h, "data": b} for h, b in sections],
                           "sources": sources, "generated": utc_now_iso()})
        elif fmt == "pdf":
            data = render_pdf(title, md)
        elif fmt == "docx":
            data = render_docx(title, md)
        else:
            raise ValidationError("Reports support md, txt, html, json, pdf, docx")
        path = self._write(out, data, force)
        return {"path": str(path), "format": fmt, "bytes": path.stat().st_size}


def render_pdf(title: str, md: str) -> bytes:
    """PDF via reportlab (optional dependency)."""
    try:
        from reportlab.lib.pagesizes import A4  # type: ignore
        from reportlab.lib.styles import getSampleStyleSheet  # type: ignore
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer  # type: ignore
    except ImportError as exc:
        raise DependencyError("PDF export needs reportlab: pip install reportlab") from exc
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
    st = getSampleStyleSheet()
    flow = []
    for ln in md.split("\n"):
        ln = xml_safe(ln)
        if not ln.strip():
            flow.append(Spacer(1, 6))
            continue
        style = st["Heading1"] if ln.startswith("# ") else st["Heading2"] if ln.startswith("## ") else st["BodyText"]
        text = html.escape(ln.lstrip("# ").lstrip("- ").strip() if ln.startswith(("#", "- ")) else ln)
        flow.append(Paragraph(text, style))
    doc.build(flow or [Paragraph("(empty)", st["BodyText"])])
    return buf.getvalue()


def render_docx(title: str, md: str) -> bytes:
    """DOCX via python-docx (optional dependency)."""
    try:
        import docx  # type: ignore
    except ImportError as exc:
        raise DependencyError("DOCX export needs python-docx: pip install python-docx") from exc
    d = docx.Document()
    d.core_properties.title = title
    for ln in md.split("\n"):
        ln = xml_safe(ln)
        if ln.startswith("# "):
            d.add_heading(ln[2:], level=0)
        elif ln.startswith("## "):
            d.add_heading(ln[3:], level=1)
        elif ln.startswith("- "):
            d.add_paragraph(ln[2:], style="List Bullet")
        elif ln.strip():
            d.add_paragraph(ln)
    bio = io.BytesIO()
    d.save(bio)
    return bio.getvalue()


# ==========================================================================
# 12. FACADE
# ==========================================================================
class MemoryIntelligence:
    """High-level facade used by the CLI and by Claude."""

    def __init__(self, db_path: Optional[Path] = None, create: bool = True):
        self.db = MemoryDB(db_path or default_db_path(), create=create)
        self.importer = Importer(self.db)
        self.search_engine = SearchEngine(self.db)
        self.analytics = Analytics(self.db)
        self.numeric = NumericEngine(self.db)
        self.projects = ProjectEngine(self.db)
        self.contradictions = ContradictionDetector(self.db)
        self.timeline = Timeline(self.db)
        self.reasoner = Reasoner(self.db)
        self.exporter = Exporter(self.db)

    def close(self) -> None:
        """Release the database."""
        self.db.close()


# ==========================================================================
# 13. CLI
# ==========================================================================
HELP_TEXT = """Memory Intelligence {v} — local memory engine (only analyses data you import).

Commands
  init                         Create / check the database
  import PATH [...]            Import file(s) or a folder (--recursive, --source, --project, --category,
                               --topic, --tags, --conversation, --encoding, --format, --dayfirst,
                               --force, --dry-run)
  search QUERY                 Search (--mode auto|keyword|fulltext|contextual|semantic, --limit,
                               filters: --from --to --period --conversation --topic --category
                               --project --role --source --tag)
  evidence QUESTION            Evidence pack: chronological records + sufficiency statement
  analyze                      Statistics (--grain day|week|month|year, --compare A B, --recurring)
  stats                        Full statistics bundle (JSON)
  timeline                     Chronology (--keyword, --milestones, filters)
  projects                     List projects and discovered project names
  project-report NAME          Detailed project report (--format md|txt|html|json|pdf|docx --out FILE)
  contradictions               Review queue of possible conflicts
  calculate EXPR               Safe arithmetic (e.g. "sqrt(2)*3+10%"), or --numbers QUERY to summarize
                               numbers found in records (units kept separate)
  export FORMAT --out FILE     Export records (--all or filters). Formats: json jsonl csv txt md html pdf docx
  backup --out FILE            Verified online backup
  restore FILE --yes           Restore from backup (makes a safety backup first)
  integrity                    Database integrity and FTS consistency check
  optimize                     ANALYZE / FTS optimise / VACUUM
  history                      Import history
  help                         This text

Examples
  memory-engine init
  memory-engine import ./chats/export.json --source chatgpt-2025
  memory-engine import ./notes --recursive --project Atlas
  memory-engine search "budget" --mode contextual --from 2025-01 --to 2025-12
  memory-engine search "\\"launch date\\"" --mode fulltext
  memory-engine analyze --grain month --compare 2025-Q1 2025-Q2 --recurring
  memory-engine calculate "(1200 - 950) / 950 * 100"
  memory-engine project-report Atlas --format md --out ./reports/atlas.md
  memory-engine export csv --all --out ./exports/archive.csv
  memory-engine backup --out ./backups/memory-2026-11-06.db

Database: $MEMORY_INTELLIGENCE_HOME/memory.db (default ~/.memory_intelligence/memory.db). Use --db to override.
""".format(v=__version__)


def build_parser() -> argparse.ArgumentParser:
    """Argument parser with all subcommands."""
    p = argparse.ArgumentParser(prog="memory_engine.py", add_help=False, description="Memory Intelligence engine")
    p.add_argument("--db", help="database path (default: $MEMORY_INTELLIGENCE_HOME/memory.db)")
    p.add_argument("-v", "--verbose", action="store_true", help="debug logging")
    p.add_argument("--json", action="store_true", help="machine-readable JSON output")
    sub = p.add_subparsers(dest="cmd")

    def filt(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--from", dest="date_from"); sp.add_argument("--to", dest="date_to")
        sp.add_argument("--period"); sp.add_argument("--conversation"); sp.add_argument("--topic")
        sp.add_argument("--category"); sp.add_argument("--project"); sp.add_argument("--role")
        sp.add_argument("--source"); sp.add_argument("--tag", action="append", default=[], dest="tags")

    sub.add_parser("init")
    sp = sub.add_parser("import"); sp.add_argument("paths", nargs="+")
    sp.add_argument("--source", default=""); sp.add_argument("--project", default="")
    sp.add_argument("--category", default=""); sp.add_argument("--topic", default="")
    sp.add_argument("--tags", default=""); sp.add_argument("--conversation", default="")
    sp.add_argument("--encoding"); sp.add_argument("--format", dest="fmt")
    sp.add_argument("--dayfirst", action="store_true"); sp.add_argument("--recursive", action="store_true")
    sp.add_argument("--force", action="store_true"); sp.add_argument("--dry-run", action="store_true")
    sp = sub.add_parser("search"); sp.add_argument("query"); sp.add_argument("--mode", default="auto")
    sp.add_argument("--limit", type=int, default=20); filt(sp)
    sp = sub.add_parser("evidence"); sp.add_argument("question"); sp.add_argument("--limit", type=int, default=25); filt(sp)
    sp = sub.add_parser("analyze"); sp.add_argument("--grain", default="month")
    sp.add_argument("--compare", nargs=2, metavar=("PERIOD_A", "PERIOD_B")); sp.add_argument("--recurring", action="store_true")
    filt(sp)
    sp = sub.add_parser("stats"); filt(sp)
    sp = sub.add_parser("timeline"); sp.add_argument("--keyword"); sp.add_argument("--milestones", action="store_true")
    sp.add_argument("--limit", type=int, default=200); filt(sp)
    sub.add_parser("projects")
    sp = sub.add_parser("project-report"); sp.add_argument("name"); sp.add_argument("--format", default="md")
    sp.add_argument("--out"); sp.add_argument("--force", action="store_true")
    sp = sub.add_parser("contradictions"); sp.add_argument("--limit", type=int, default=100)
    sp = sub.add_parser("calculate"); sp.add_argument("expr", nargs="?"); sp.add_argument("--numbers", metavar="QUERY")
    sp.add_argument("--unit-trend", metavar="UNIT")
    sp = sub.add_parser("export"); sp.add_argument("format"); sp.add_argument("--out", required=True)
    sp.add_argument("--all", action="store_true"); sp.add_argument("--force", action="store_true")
    sp.add_argument("--query"); sp.add_argument("--limit", type=int, default=100000); filt(sp)
    sp = sub.add_parser("backup"); sp.add_argument("--out", required=True)
    sp = sub.add_parser("restore"); sp.add_argument("src"); sp.add_argument("--yes", action="store_true")
    sub.add_parser("integrity"); sub.add_parser("optimize"); sub.add_parser("history")
    sub.add_parser("help")
    return p


def _filters(a: argparse.Namespace) -> SearchFilters:
    return SearchFilters(date_from=getattr(a, "date_from", None), date_to=getattr(a, "date_to", None),
                         period=getattr(a, "period", None), conversation=getattr(a, "conversation", None),
                         topic=getattr(a, "topic", None), category=getattr(a, "category", None),
                         project=getattr(a, "project", None), role=getattr(a, "role", None),
                         source=getattr(a, "source", None), tags=list(getattr(a, "tags", []) or []))


def _emit(obj: Any, as_json: bool) -> None:
    """Print a result as JSON or a readable summary."""
    if as_json or not isinstance(obj, (str,)):
        print(jdumps(obj))
    else:
        print(obj)


def _print_results(res: Dict[str, Any]) -> None:
    print(f"Method: {res['method']}  |  results: {res['count']}")
    for n in res.get("notes", []):
        print(f"Note: {n}")
    for r in res["results"]:
        print(f"\n[{r['record_id']}] {r['ts'] or 'undated'} · {r['role']} · conv={r['conversation_id']} · source={r['source']}")
        print(f"   {r['snippet']}")


def run(argv: Optional[List[str]] = None) -> int:
    """CLI entry point. Returns process exit code."""
    parser = build_parser()
    if not argv:
        print(HELP_TEXT)
        return 0
    try:
        a = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code or 2)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.WARNING, format="%(levelname)s %(message)s")
    if a.cmd in (None, "help"):
        print(HELP_TEXT)
        return 0
    try:
        mi = MemoryIntelligence(Path(a.db) if a.db else None, create=True)
    except (sqlite3.DatabaseError, OSError, MemoryEngineError) as exc:
        print(f"error: cannot open database: {exc}", file=sys.stderr)
        return 1
    try:
        return _dispatch(mi, a)
    except ConfirmationRequired as exc:
        print(f"Confirmation required: {exc}", file=sys.stderr)
        return 3
    except NotFoundError as exc:
        print(f"Not found: {exc}", file=sys.stderr)
        return 4
    except MemoryEngineError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except sqlite3.DatabaseError as exc:
        print(f"database error: {exc}", file=sys.stderr)
        return 1
    finally:
        mi.close()


def _dispatch(mi: MemoryIntelligence, a: argparse.Namespace) -> int:
    cmd = a.cmd
    if cmd == "init":
        ok = mi.db.integrity()
        _emit({"database": str(mi.db.path), "schema_version": SCHEMA_VERSION, "fts5": mi.db.has_fts(),
               "records": mi.db.record_count(), "integrity": ok}, a.json)
        return 0 if ok["ok"] else 1
    if cmd == "import":
        opts = ImportOptions(source=a.source, project=a.project, category=a.category, topic=a.topic,
                             tags=split_list(a.tags), conversation_id=a.conversation, encoding=a.encoding,
                             fmt=a.fmt, dayfirst=a.dayfirst, recursive=a.recursive, force=a.force, dry_run=a.dry_run)
        results: List[ImportResult] = []
        for p in a.paths:
            try:
                results += mi.importer.import_path(Path(p), opts)
            except MemoryEngineError as exc:
                results.append(ImportResult(file=p, status="failed", message=str(exc)))
        if mi.db.record_count():
            mi.projects.refresh()
        if a.json:
            print(jdumps([r.as_dict() for r in results]))
        else:
            for r in results:
                print(f"{r.status:18} {r.file}  {r.message}")
                for e in r.errors[:5]:
                    print(f"    invalid: {e}")
                if len(r.errors) > 5:
                    print(f"    ... {len(r.errors) - 5} more invalid entries")
        return 0 if all(r.status != "failed" for r in results) else 1
    if cmd == "search":
        res = mi.search_engine.search(a.query, mode=a.mode, limit=a.limit, filters=_filters(a))
        _emit(res, True) if a.json else _print_results(res)
        return 0
    if cmd == "evidence":
        ev = mi.reasoner.evidence(a.question, a.limit, _filters(a))
        _emit(ev, True)
        return 0
    if cmd == "analyze":
        f = _filters(a)
        out: Dict[str, Any] = {"overview": mi.analytics.overview(f), "activity": mi.analytics.activity(a.grain, f)}
        if a.compare:
            out["comparison"] = mi.analytics.compare_periods(a.compare[0], a.compare[1], f)
        if a.recurring:
            out["recurring_questions"] = mi.analytics.recurring_questions(2, 20, f)
        _emit(out, True)
        return 0
    if cmd == "stats":
        _emit(mi.analytics.full(_filters(a)), True)
        return 0
    if cmd == "timeline":
        t = mi.timeline.build(_filters(a), a.keyword, a.milestones, limit=max(1, a.limit))
        if a.json:
            print(jdumps(t))
        else:
            for e in t:
                tag = f" [{', '.join(e['kinds'])}]" if e["kinds"] else ""
                print(f"{(e['ts'] or '')[:10]}  {e['role']:9} {e['record_id']}{tag}\n    {e['snippet']}")
            print(f"\n{len(t)} entries")
        return 0
    if cmd == "projects":
        out = {"stored_projects": mi.projects.names(), "discovered_names": mi.projects.discover(3, 20)}
        _emit(out, True)
        return 0
    if cmd == "project-report":
        rep = mi.projects.report(a.name)
        if a.out:
            info = mi.exporter.export_report(f"Project report: {a.name}",
                                             [(k, v) for k, v in rep.items() if k not in ("project",)],
                                             [f"Records in database for project {a.name!r}"], a.format,
                                             Path(a.out), a.force)
            _emit(info, True)
        else:
            _emit(rep, True)
        return 0
    if cmd == "contradictions":
        q = mi.contradictions.review_queue(a.limit)
        _emit({"review_queue": q, "count": len(q),
               "note": "Each item needs human review. Updates over time are not automatically contradictions."}, True)
        return 0
    if cmd == "calculate":
        if a.numbers:
            items = mi.numeric.extract_from_search(a.numbers, _filters(a))
            out = mi.numeric.summarize(items)
            if a.unit_trend:
                out["trend"] = mi.numeric.trend(items, a.unit_trend)
            out["items_sample"] = items[:50]
            _emit(out, True)
            return 0
        if not a.expr:
            raise ValidationError("Provide an expression or --numbers QUERY")
        _emit(mi.numeric.calc.evaluate(a.expr), True)
        return 0
    if cmd == "export":
        out_path = Path(a.out)
        f = _filters(a)
        if a.all:
            rows = mi.db.conn.execute("SELECT * FROM records ORDER BY ts, seq").fetchall()
            items = [row_to_dict(r) for r in rows]
            title = "Complete memory archive"
        else:
            res = mi.search_engine.search(a.query, mode="keyword", limit=min(a.limit, 1000), filters=f) if a.query \
                else None
            if res is not None:
                items = res["results"]
            else:
                w, p = f.clauses()
                sql = "SELECT r.* FROM records r" + (" WHERE " + " AND ".join(w) if w else "") + " ORDER BY r.ts, r.seq LIMIT ?"
                items = [row_to_dict(r) for r in mi.db.conn.execute(sql, p + [a.limit])]
            title = "Selective memory export"
        info = mi.exporter.export_records(items, a.format, out_path, a.force, title)
        _emit(info, True)
        return 0
    if cmd == "backup":
        _emit(mi.db.backup(Path(a.out)), True)
        return 0
    if cmd == "restore":
        if not a.yes:
            raise ConfirmationRequired("Restore replaces all data. Re-run with --yes to confirm.")
        _emit(mi.db.restore(Path(a.src), confirm=True), True)
        return 0
    if cmd == "integrity":
        res = mi.db.integrity()
        _emit(res, True)
        return 0 if res["ok"] else 1
    if cmd == "optimize":
        _emit(mi.db.optimize(), True)
        return 0
    if cmd == "history":
        _emit(mi.db.import_history(200), True)
        return 0
    raise ValidationError(f"Unknown command {cmd!r}")


def main() -> None:
    """Module entry point."""
    sys.exit(run(sys.argv[1:]))


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:  # output piped into `head` etc.
        sys.stderr.close()
        sys.exit(0)
